"""
DSA Explorer and Visualiser App
================================
An interactive Data Structures and Algorithms Explorer built with Pygame.
Combines algorithm visualizations with puzzle-like challenges.

Modules:
  Phase 1 - Data Structures : Stack, Queue, Linked List, BST
  Phase 2 - Algorithm Visualizer : Sorting (Bubble/Selection/Merge),
                                    Graph Traversal (BFS/DFS), Min-Heap
  Phase 3 - Puzzle Challenges : Pathfinding (Dijkstra/A*),
                                  Event Queue Simulator, DP Grid Puzzle

How to run:
  python main.py   (from the dsa-explorer/ folder)
  Press ESC inside any module to return to the main menu.
"""

import pygame
import sys
from utils.colors import (
    DARK_GRAY, PRIMARY, PRIMARY_DARK, PRIMARY_LIGHT,
    MENU_BG, STACK_COLOR, LINKED_LIST_COLOR, BST_COLOR,
    SUCCESS
)
from utils.ui import Button

# Module imports
from modules.data_structures import data_structures_module
from modules.sorting import sorting_module
from modules.graphs import graphs_module
from modules.heap import heap_module
from modules.puzzles.puzzles_menu import puzzles_module


WIDTH, HEIGHT = 800, 600
FPS = 30


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("DSA Explorer and Visualiser")
    clock = pygame.time.Clock()

    # Main menu buttons
    btn_w, btn_h = 260, 55
    cx = WIDTH // 2 - btn_w // 2
    buttons = [
        ("Data Structures", Button(cx, 180, btn_w, btn_h, "Data Structures",
                                   STACK_COLOR, font_size=24)),
        ("Sorting", Button(cx, 250, btn_w, btn_h, "Sorting",
                           PRIMARY, font_size=24)),
        ("Graphs", Button(cx, 320, btn_w, btn_h, "Graphs",
                          LINKED_LIST_COLOR, font_size=24)),
        ("Heap", Button(cx, 390, btn_w, btn_h, "Heap",
                        BST_COLOR, font_size=24)),
        ("Puzzles", Button(cx, 460, btn_w, btn_h, "Puzzles",
                           SUCCESS, font_size=24)),
    ]

    module_map = {
        "Data Structures": data_structures_module,
        "Sorting": sorting_module,
        "Graphs": graphs_module,
        "Heap": heap_module,
        "Puzzles": puzzles_module,
    }

    title_font = pygame.font.SysFont("Arial", 40, bold=True)
    subtitle_font = pygame.font.SysFont("Arial", 20)
    footer_font = pygame.font.SysFont("Arial", 14)

    running = True
    while running:
        # --- Main menu ---
        screen.fill(MENU_BG)

        # Title
        title_txt = title_font.render("DSA Explorer & Visualiser", True, PRIMARY_DARK)
        screen.blit(title_txt, (WIDTH // 2 - title_txt.get_width() // 2, 50))
        sub_txt = subtitle_font.render(
            "Explore data structures and algorithms interactively", True, DARK_GRAY)
        screen.blit(sub_txt, (WIDTH // 2 - sub_txt.get_width() // 2, 100))

        # Decorative line
        pygame.draw.line(screen, PRIMARY_LIGHT, (100, 140), (WIDTH - 100, 140), 2)

        mouse_pos = pygame.mouse.get_pos()
        for _, btn in buttons:
            btn.update(mouse_pos)
            btn.draw(screen)

        # Footer
        ft = footer_font.render("Press ESC in any module to return here", True, DARK_GRAY)
        screen.blit(ft, (WIDTH // 2 - ft.get_width() // 2, HEIGHT - 30))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for name, btn in buttons:
                    if btn.is_clicked(event.pos):
                        result = module_map[name](screen, clock, WIDTH, HEIGHT)
                        if result is None:
                            running = False

        clock.tick(FPS)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
