"""Unit tests for Phase 2: Graph BFS / DFS."""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.graphs import Graph


class TestGraph(unittest.TestCase):

    def _sample_graph(self):
        g = Graph()
        for u, v in [(0, 1), (0, 2), (1, 3), (2, 3), (3, 4)]:
            g.add_edge(u, v)
        return g

    def test_add_node(self):
        g = Graph()
        g.add_node(0)
        g.add_node(1)
        self.assertIn(0, g.nodes())
        self.assertIn(1, g.nodes())

    def test_add_edge(self):
        g = Graph()
        g.add_edge(0, 1)
        self.assertIn(1, g.neighbors(0))
        self.assertIn(0, g.neighbors(1))

    def test_remove_node(self):
        g = Graph()
        g.add_edge(0, 1)
        g.add_edge(1, 2)
        g.remove_node(1)
        self.assertNotIn(1, g.nodes())
        self.assertEqual(g.neighbors(0), [])
        self.assertEqual(g.neighbors(2), [])

    def test_edges(self):
        g = self._sample_graph()
        edges = g.edges()
        self.assertEqual(len(edges), 5)

    def test_bfs_order(self):
        g = self._sample_graph()
        order = g.bfs(0)
        self.assertEqual(order[0], 0)
        self.assertIn(1, order)
        self.assertIn(4, order)
        self.assertEqual(len(order), 5)

    def test_bfs_visits_all_reachable(self):
        g = Graph()
        g.add_edge(0, 1)
        g.add_edge(1, 2)
        g.add_node(3)  # disconnected
        order = g.bfs(0)
        self.assertEqual(set(order), {0, 1, 2})

    def test_bfs_empty_start(self):
        g = Graph()
        self.assertEqual(g.bfs(99), [])

    def test_dfs_order(self):
        g = self._sample_graph()
        order = g.dfs(0)
        self.assertEqual(order[0], 0)
        self.assertEqual(len(order), 5)

    def test_dfs_visits_all_reachable(self):
        g = Graph()
        g.add_edge(0, 1)
        g.add_edge(1, 2)
        g.add_node(3)
        order = g.dfs(0)
        self.assertEqual(set(order), {0, 1, 2})

    def test_dfs_empty_start(self):
        g = Graph()
        self.assertEqual(g.dfs(99), [])

    def test_single_node(self):
        g = Graph()
        g.add_node(0)
        self.assertEqual(g.bfs(0), [0])
        self.assertEqual(g.dfs(0), [0])

    def test_bfs_steps_generator(self):
        g = self._sample_graph()
        steps = list(g.bfs_steps(0))
        self.assertGreater(len(steps), 0)
        # Last step should have None as current node
        self.assertIsNone(steps[-1][0])

    def test_dfs_steps_generator(self):
        g = self._sample_graph()
        steps = list(g.dfs_steps(0))
        self.assertGreater(len(steps), 0)
        self.assertIsNone(steps[-1][0])


if __name__ == "__main__":
    unittest.main()
