"""Unit tests for Phase 1: Data Structures (Stack, Queue, LinkedList, BST)."""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.data_structures import Stack, Queue, LinkedList, BST


class TestStack(unittest.TestCase):

    def test_push_and_pop(self):
        s = Stack()
        s.push(10)
        s.push(20)
        s.push(30)
        self.assertEqual(s.pop(), 30)
        self.assertEqual(s.pop(), 20)
        self.assertEqual(s.pop(), 10)

    def test_pop_empty(self):
        s = Stack()
        self.assertIsNone(s.pop())

    def test_peek(self):
        s = Stack()
        s.push(5)
        s.push(15)
        self.assertEqual(s.peek(), 15)
        self.assertEqual(s.size(), 2)

    def test_peek_empty(self):
        s = Stack()
        self.assertIsNone(s.peek())

    def test_is_empty(self):
        s = Stack()
        self.assertTrue(s.is_empty())
        s.push(1)
        self.assertFalse(s.is_empty())

    def test_size(self):
        s = Stack()
        self.assertEqual(s.size(), 0)
        for i in range(5):
            s.push(i)
        self.assertEqual(s.size(), 5)

    def test_max_size(self):
        s = Stack(max_size=3)
        self.assertTrue(s.push(1))
        self.assertTrue(s.push(2))
        self.assertTrue(s.push(3))
        self.assertFalse(s.push(4))
        self.assertEqual(s.size(), 3)

    def test_lifo_order(self):
        s = Stack()
        for v in [1, 2, 3, 4, 5]:
            s.push(v)
        result = []
        while not s.is_empty():
            result.append(s.pop())
        self.assertEqual(result, [5, 4, 3, 2, 1])


class TestQueue(unittest.TestCase):

    def test_enqueue_and_dequeue(self):
        q = Queue()
        q.enqueue(10)
        q.enqueue(20)
        q.enqueue(30)
        self.assertEqual(q.dequeue(), 10)
        self.assertEqual(q.dequeue(), 20)
        self.assertEqual(q.dequeue(), 30)

    def test_dequeue_empty(self):
        q = Queue()
        self.assertIsNone(q.dequeue())

    def test_front(self):
        q = Queue()
        q.enqueue(5)
        q.enqueue(15)
        self.assertEqual(q.front(), 5)
        self.assertEqual(q.size(), 2)

    def test_front_empty(self):
        q = Queue()
        self.assertIsNone(q.front())

    def test_is_empty(self):
        q = Queue()
        self.assertTrue(q.is_empty())
        q.enqueue(1)
        self.assertFalse(q.is_empty())

    def test_fifo_order(self):
        q = Queue()
        for v in [1, 2, 3, 4, 5]:
            q.enqueue(v)
        result = []
        while not q.is_empty():
            result.append(q.dequeue())
        self.assertEqual(result, [1, 2, 3, 4, 5])

    def test_max_size(self):
        q = Queue(max_size=3)
        self.assertTrue(q.enqueue(1))
        self.assertTrue(q.enqueue(2))
        self.assertTrue(q.enqueue(3))
        self.assertFalse(q.enqueue(4))


class TestLinkedList(unittest.TestCase):

    def test_insert_at_head(self):
        ll = LinkedList()
        ll.insert_at_head(3)
        ll.insert_at_head(2)
        ll.insert_at_head(1)
        self.assertEqual(ll.to_list(), [1, 2, 3])

    def test_insert_at_tail(self):
        ll = LinkedList()
        ll.insert_at_tail(1)
        ll.insert_at_tail(2)
        ll.insert_at_tail(3)
        self.assertEqual(ll.to_list(), [1, 2, 3])

    def test_delete_head(self):
        ll = LinkedList()
        ll.insert_at_tail(1)
        ll.insert_at_tail(2)
        ll.insert_at_tail(3)
        self.assertTrue(ll.delete_node(1))
        self.assertEqual(ll.to_list(), [2, 3])

    def test_delete_middle(self):
        ll = LinkedList()
        ll.insert_at_tail(1)
        ll.insert_at_tail(2)
        ll.insert_at_tail(3)
        self.assertTrue(ll.delete_node(2))
        self.assertEqual(ll.to_list(), [1, 3])

    def test_delete_tail(self):
        ll = LinkedList()
        ll.insert_at_tail(1)
        ll.insert_at_tail(2)
        ll.insert_at_tail(3)
        self.assertTrue(ll.delete_node(3))
        self.assertEqual(ll.to_list(), [1, 2])

    def test_delete_not_found(self):
        ll = LinkedList()
        ll.insert_at_tail(1)
        self.assertFalse(ll.delete_node(99))

    def test_delete_empty(self):
        ll = LinkedList()
        self.assertFalse(ll.delete_node(1))

    def test_reverse(self):
        ll = LinkedList()
        for v in [1, 2, 3, 4, 5]:
            ll.insert_at_tail(v)
        ll.reverse()
        self.assertEqual(ll.to_list(), [5, 4, 3, 2, 1])

    def test_reverse_single(self):
        ll = LinkedList()
        ll.insert_at_tail(1)
        ll.reverse()
        self.assertEqual(ll.to_list(), [1])

    def test_reverse_empty(self):
        ll = LinkedList()
        ll.reverse()
        self.assertEqual(ll.to_list(), [])

    def test_size(self):
        ll = LinkedList()
        self.assertEqual(ll.size(), 0)
        ll.insert_at_tail(1)
        ll.insert_at_tail(2)
        self.assertEqual(ll.size(), 2)

    def test_search(self):
        ll = LinkedList()
        for v in [10, 20, 30]:
            ll.insert_at_tail(v)
        self.assertEqual(ll.search(20), 1)
        self.assertEqual(ll.search(10), 0)
        self.assertEqual(ll.search(99), -1)

    # ── insert_at_position tests (required by assignment) ──

    def test_insert_at_position_middle(self):
        """Assignment test: Insert node with value 10 at position 2."""
        ll = LinkedList()
        for v in [1, 2, 3, 4]:
            ll.insert_at_tail(v)
        ll.insert_at_position(2, 10)
        result = ll.to_list()
        self.assertEqual(result[2], 10)               # node at correct location
        self.assertEqual(result, [1, 2, 10, 3, 4])

    def test_insert_at_position_head(self):
        ll = LinkedList()
        ll.insert_at_tail(5)
        ll.insert_at_position(0, 1)
        self.assertEqual(ll.to_list()[0], 1)

    def test_insert_at_position_tail(self):
        ll = LinkedList()
        for v in [1, 2, 3]:
            ll.insert_at_tail(v)
        ll.insert_at_position(100, 99)                # beyond end → appends
        self.assertEqual(ll.to_list()[-1], 99)

    def test_insert_at_position_empty_list(self):
        ll = LinkedList()
        ll.insert_at_position(5, 42)
        self.assertEqual(ll.to_list(), [42])

    def test_insert_at_position_size_increases(self):
        ll = LinkedList()
        for v in [1, 2, 3]:
            ll.insert_at_tail(v)
        ll.insert_at_position(1, 99)
        self.assertEqual(ll.size(), 4)


class TestBST(unittest.TestCase):

    def test_insert_and_inorder(self):
        bst = BST()
        for v in [5, 3, 7, 1, 4]:
            bst.insert(v)
        self.assertEqual(bst.inorder(), [1, 3, 4, 5, 7])

    def test_preorder(self):
        bst = BST()
        for v in [5, 3, 7, 1, 4]:
            bst.insert(v)
        self.assertEqual(bst.preorder(), [5, 3, 1, 4, 7])

    def test_postorder(self):
        bst = BST()
        for v in [5, 3, 7, 1, 4]:
            bst.insert(v)
        self.assertEqual(bst.postorder(), [1, 4, 3, 7, 5])

    def test_search_found(self):
        bst = BST()
        for v in [5, 3, 7]:
            bst.insert(v)
        self.assertTrue(bst.search(3))
        self.assertTrue(bst.search(7))

    def test_search_not_found(self):
        bst = BST()
        bst.insert(5)
        self.assertFalse(bst.search(10))

    def test_search_empty(self):
        bst = BST()
        self.assertFalse(bst.search(1))

    def test_duplicate_insert(self):
        bst = BST()
        bst.insert(5)
        bst.insert(5)
        self.assertEqual(bst.inorder(), [5])

    def test_single_node(self):
        bst = BST()
        bst.insert(42)
        self.assertEqual(bst.inorder(), [42])
        self.assertEqual(bst.preorder(), [42])
        self.assertEqual(bst.postorder(), [42])

    def test_sorted_insert(self):
        bst = BST()
        for v in [1, 2, 3, 4, 5]:
            bst.insert(v)
        self.assertEqual(bst.inorder(), [1, 2, 3, 4, 5])

    # ── BST delete tests (required by assignment) ──

    def test_delete_leaf_node(self):
        """Case 0 children: delete a leaf."""
        bst = BST()
        for v in [5, 3, 7]:
            bst.insert(v)
        bst.delete(3)
        self.assertEqual(bst.inorder(), [5, 7])

    def test_delete_one_child(self):
        """Case 1 child: node with single child."""
        bst = BST()
        for v in [5, 3, 7, 2]:
            bst.insert(v)
        bst.delete(3)                             # 3 has only left child (2)
        self.assertEqual(bst.inorder(), [2, 5, 7])

    def test_delete_two_children(self):
        """Case 2 children: replace with in-order successor."""
        bst = BST()
        for v in [5, 3, 7, 2, 4]:
            bst.insert(v)
        bst.delete(3)                             # 3 has two children (2, 4)
        self.assertNotIn(3, bst.inorder())
        self.assertIn(2, bst.inorder())
        self.assertIn(4, bst.inorder())

    def test_delete_root(self):
        """Delete root node."""
        bst = BST()
        for v in [5, 3, 7]:
            bst.insert(v)
        bst.delete(5)
        self.assertNotIn(5, bst.inorder())
        self.assertEqual(len(bst.inorder()), 2)

    def test_delete_nonexistent(self):
        """Delete a key that does not exist — should not raise."""
        bst = BST()
        bst.insert(5)
        bst.delete(99)
        self.assertEqual(bst.inorder(), [5])

    def test_bst_inorder_assignment_example(self):
        """Assignment sample: Insert [50,30,70] → inorder = [30,50,70]."""
        bst = BST()
        for v in [50, 30, 70]:
            bst.insert(v)
        self.assertEqual(bst.inorder(), [30, 50, 70])


if __name__ == "__main__":
    unittest.main()
