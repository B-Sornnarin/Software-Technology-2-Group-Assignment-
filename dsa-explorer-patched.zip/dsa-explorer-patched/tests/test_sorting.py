"""Unit tests for Phase 2: Sorting algorithms."""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.sorting import bubble_sort, selection_sort, merge_sort


class TestBubbleSort(unittest.TestCase):

    def test_sorted(self):
        self.assertEqual(bubble_sort([1, 2, 3, 4, 5]), [1, 2, 3, 4, 5])

    def test_reverse(self):
        self.assertEqual(bubble_sort([5, 4, 3, 2, 1]), [1, 2, 3, 4, 5])

    def test_random(self):
        self.assertEqual(bubble_sort([3, 1, 4, 1, 5, 9, 2, 6]), [1, 1, 2, 3, 4, 5, 6, 9])

    def test_empty(self):
        self.assertEqual(bubble_sort([]), [])

    def test_single(self):
        self.assertEqual(bubble_sort([42]), [42])

    def test_duplicates(self):
        self.assertEqual(bubble_sort([3, 3, 3, 1, 1]), [1, 1, 3, 3, 3])

    def test_negative(self):
        self.assertEqual(bubble_sort([-3, -1, -2]), [-3, -2, -1])


class TestSelectionSort(unittest.TestCase):

    def test_sorted(self):
        self.assertEqual(selection_sort([1, 2, 3]), [1, 2, 3])

    def test_reverse(self):
        self.assertEqual(selection_sort([5, 4, 3, 2, 1]), [1, 2, 3, 4, 5])

    def test_random(self):
        self.assertEqual(selection_sort([64, 25, 12, 22, 11]), [11, 12, 22, 25, 64])

    def test_empty(self):
        self.assertEqual(selection_sort([]), [])

    def test_single(self):
        self.assertEqual(selection_sort([7]), [7])

    def test_duplicates(self):
        self.assertEqual(selection_sort([2, 2, 1, 1, 3]), [1, 1, 2, 2, 3])


class TestMergeSort(unittest.TestCase):

    def test_sorted(self):
        self.assertEqual(merge_sort([1, 2, 3, 4]), [1, 2, 3, 4])

    def test_reverse(self):
        self.assertEqual(merge_sort([4, 3, 2, 1]), [1, 2, 3, 4])

    def test_random(self):
        self.assertEqual(merge_sort([38, 27, 43, 3, 9, 82, 10]),
                         [3, 9, 10, 27, 38, 43, 82])

    def test_empty(self):
        self.assertEqual(merge_sort([]), [])

    def test_single(self):
        self.assertEqual(merge_sort([1]), [1])

    def test_duplicates(self):
        self.assertEqual(merge_sort([5, 3, 5, 3, 1]), [1, 3, 3, 5, 5])

    def test_negative(self):
        self.assertEqual(merge_sort([-5, 0, 5, -10, 10]), [-10, -5, 0, 5, 10])

    def test_large(self):
        import random
        arr = list(range(100))
        random.shuffle(arr)
        self.assertEqual(merge_sort(arr), list(range(100)))


if __name__ == "__main__":
    unittest.main()
