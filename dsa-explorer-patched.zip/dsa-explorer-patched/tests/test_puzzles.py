"""Unit tests for Phase 3: Puzzles (Pathfinding, Event Queue, DP)."""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.puzzles.pathfinding import dijkstra, astar
from modules.puzzles.event_queue import Event, EventQueue
from modules.puzzles.dp_puzzle import count_paths, reconstruct_path


# ---------- Pathfinding ----------

class TestDijkstra(unittest.TestCase):

    def test_simple_path(self):
        grid = [[0] * 5 for _ in range(5)]
        path, explored = dijkstra(grid, (0, 0), (4, 4))
        self.assertEqual(path[0], (0, 0))
        self.assertEqual(path[-1], (4, 4))
        self.assertEqual(len(path), 9)  # Manhattan distance + 1

    def test_no_path(self):
        grid = [[0] * 5 for _ in range(5)]
        # Wall off destination
        grid[3][4] = 1
        grid[4][3] = 1
        path, _ = dijkstra(grid, (0, 0), (4, 4))
        self.assertEqual(path, [])

    def test_start_is_end(self):
        grid = [[0] * 3 for _ in range(3)]
        path, explored = dijkstra(grid, (1, 1), (1, 1))
        self.assertEqual(path, [(1, 1)])

    def test_wall_avoidance(self):
        grid = [[0] * 5 for _ in range(5)]
        for r in range(4):
            grid[r][2] = 1  # vertical wall with gap at bottom
        path, _ = dijkstra(grid, (0, 0), (0, 4))
        self.assertGreater(len(path), 0)
        for r, c in path:
            self.assertEqual(grid[r][c], 0)


class TestAstar(unittest.TestCase):

    def test_simple_path(self):
        grid = [[0] * 5 for _ in range(5)]
        path, explored = astar(grid, (0, 0), (4, 4))
        self.assertEqual(path[0], (0, 0))
        self.assertEqual(path[-1], (4, 4))
        self.assertEqual(len(path), 9)

    def test_no_path(self):
        grid = [[0] * 5 for _ in range(5)]
        grid[3][4] = 1
        grid[4][3] = 1
        path, _ = astar(grid, (0, 0), (4, 4))
        self.assertEqual(path, [])

    def test_astar_more_efficient(self):
        """A* should explore fewer or equal cells than Dijkstra."""
        grid = [[0] * 10 for _ in range(10)]
        _, explored_d = dijkstra(grid, (0, 0), (9, 9))
        _, explored_a = astar(grid, (0, 0), (9, 9))
        self.assertLessEqual(len(explored_a), len(explored_d))

    def test_start_is_wall(self):
        grid = [[0] * 3 for _ in range(3)]
        grid[0][0] = 1
        path, _ = astar(grid, (0, 0), (2, 2))
        self.assertEqual(path, [])


# ---------- Event Queue ----------

class TestEventQueue(unittest.TestCase):

    def test_schedule_and_process(self):
        eq = EventQueue()
        eq.schedule(Event("A", 1, 3))
        eq.schedule(Event("B", 2, 1))
        eq.schedule(Event("C", 3, 2))
        ev = eq.process_next()
        self.assertEqual(ev.name, "B")  # lowest priority value

    def test_priority_ordering(self):
        eq = EventQueue()
        eq.schedule(Event("Low", 1, 10))
        eq.schedule(Event("High", 2, 1))
        eq.schedule(Event("Med", 3, 5))
        order = []
        while not eq.is_empty():
            order.append(eq.process_next().name)
        self.assertEqual(order, ["High", "Med", "Low"])

    def test_same_priority_time_order(self):
        eq = EventQueue()
        eq.schedule(Event("Second", 2, 1))
        eq.schedule(Event("First", 1, 1))
        ev = eq.process_next()
        self.assertEqual(ev.name, "First")

    def test_process_empty(self):
        eq = EventQueue()
        self.assertIsNone(eq.process_next())

    def test_size(self):
        eq = EventQueue()
        self.assertEqual(eq.size(), 0)
        eq.schedule(Event("X", 1, 1))
        eq.schedule(Event("Y", 2, 2))
        self.assertEqual(eq.size(), 2)

    def test_peek(self):
        eq = EventQueue()
        eq.schedule(Event("A", 1, 5))
        eq.schedule(Event("B", 2, 1))
        self.assertEqual(eq.peek().name, "B")
        self.assertEqual(eq.size(), 2)  # peek doesn't remove


# ---------- DP Puzzle ----------

class TestDPPuzzle(unittest.TestCase):

    def test_no_obstacles(self):
        grid = [[0] * 3 for _ in range(3)]
        dp, total = count_paths(grid)
        self.assertEqual(total, 6)

    def test_with_obstacle(self):
        grid = [[0] * 3 for _ in range(3)]
        grid[1][1] = 1
        dp, total = count_paths(grid)
        self.assertEqual(total, 2)

    def test_blocked_start(self):
        grid = [[0] * 3 for _ in range(3)]
        grid[0][0] = 1
        _, total = count_paths(grid)
        self.assertEqual(total, 0)

    def test_blocked_end(self):
        grid = [[0] * 3 for _ in range(3)]
        grid[2][2] = 1
        _, total = count_paths(grid)
        self.assertEqual(total, 0)

    def test_single_cell(self):
        grid = [[0]]
        dp, total = count_paths(grid)
        self.assertEqual(total, 1)

    def test_reconstruct_path(self):
        grid = [[0] * 3 for _ in range(3)]
        dp, total = count_paths(grid)
        path = reconstruct_path(dp, grid)
        self.assertEqual(path[0], (0, 0))
        self.assertEqual(path[-1], (2, 2))
        self.assertEqual(len(path), 5)  # 3+3-1

    def test_reconstruct_no_path(self):
        grid = [[0] * 3 for _ in range(3)]
        grid[0][1] = 1
        grid[1][0] = 1
        dp, total = count_paths(grid)
        self.assertEqual(total, 0)
        path = reconstruct_path(dp, grid)
        self.assertEqual(path, [])

    def test_larger_grid(self):
        grid = [[0] * 4 for _ in range(4)]
        dp, total = count_paths(grid)
        self.assertEqual(total, 20)  # C(6,3)

    def test_full_wall_row(self):
        grid = [[0] * 4 for _ in range(4)]
        grid[1][0] = 1
        grid[1][1] = 1
        grid[1][2] = 1
        grid[1][3] = 1
        _, total = count_paths(grid)
        self.assertEqual(total, 0)


if __name__ == "__main__":
    unittest.main()
