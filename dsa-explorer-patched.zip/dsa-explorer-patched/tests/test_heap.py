"""Unit tests for Phase 2: Min-Heap."""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from modules.heap import MinHeap


class TestMinHeap(unittest.TestCase):

    def test_insert_and_peek(self):
        h = MinHeap()
        h.insert(10)
        h.insert(5)
        h.insert(15)
        self.assertEqual(h.peek(), 5)

    def test_extract_min(self):
        h = MinHeap()
        for v in [20, 10, 30, 5, 15]:
            h.insert(v)
        self.assertEqual(h.extract_min(), 5)
        self.assertEqual(h.extract_min(), 10)
        self.assertEqual(h.extract_min(), 15)

    def test_extract_empty(self):
        h = MinHeap()
        self.assertIsNone(h.extract_min())

    def test_peek_empty(self):
        h = MinHeap()
        self.assertIsNone(h.peek())

    def test_size(self):
        h = MinHeap()
        self.assertEqual(h.size(), 0)
        h.insert(1)
        h.insert(2)
        self.assertEqual(h.size(), 2)
        h.extract_min()
        self.assertEqual(h.size(), 1)

    def test_is_empty(self):
        h = MinHeap()
        self.assertTrue(h.is_empty())
        h.insert(1)
        self.assertFalse(h.is_empty())

    def test_heap_property(self):
        """All extracted elements should come out in sorted order."""
        h = MinHeap()
        import random
        values = random.sample(range(100), 20)
        for v in values:
            h.insert(v)
        result = []
        while not h.is_empty():
            result.append(h.extract_min())
        self.assertEqual(result, sorted(values))

    def test_to_list(self):
        h = MinHeap()
        h.insert(3)
        h.insert(1)
        h.insert(2)
        lst = h.to_list()
        self.assertEqual(len(lst), 3)
        self.assertEqual(lst[0], 1)  # min at root

    def test_single_element(self):
        h = MinHeap()
        h.insert(42)
        self.assertEqual(h.extract_min(), 42)
        self.assertTrue(h.is_empty())

    def test_duplicate_values(self):
        h = MinHeap()
        h.insert(5)
        h.insert(5)
        h.insert(5)
        self.assertEqual(h.extract_min(), 5)
        self.assertEqual(h.size(), 2)


if __name__ == "__main__":
    unittest.main()
