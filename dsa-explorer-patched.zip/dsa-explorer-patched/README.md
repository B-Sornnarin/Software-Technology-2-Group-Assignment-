# DSA Explorer and Visualiser

An interactive Data Structures and Algorithms Explorer built with **Pygame**.
Combines algorithm visualizations with puzzle-like challenges.

## Requirements

- Python 3.8+
- Pygame 2.5+

## Installation

```bash
pip install -r requirements.txt
```

## Running the App

```bash
python main.py
```

Navigate using the main menu. Press **ESC** in any module to return to the menu.

## Modules

### Phase 1: Data Structure Playground
- **Stack** — Push/Pop/Peek with LIFO visualization
- **Queue** — Enqueue/Dequeue/Front with FIFO visualization
- **Linked List** — Insert (head/tail), Delete, Reverse with pointer visualization
- **Binary Search Tree** — Insert, Search, In/Pre/Post-order traversals

### Phase 2: Algorithm Visualizer
- **Sorting** — Bubble Sort, Selection Sort, Merge Sort with animated bar charts and speed control
- **Graph Traversal** — BFS and DFS on an interactive graph (add nodes, edges, select start)
- **Heap** — Min-heap insertion and extraction shown step-by-step as a tree

### Phase 3: Puzzle Challenges
- **Pathfinding Puzzle** — Place walls on a grid; run Dijkstra or A* to find the shortest path
- **Event Queue Simulator** — Schedule events by priority; watch heap-based processing
- **DP Grid Puzzle** — Count unique paths with obstacles; visualize the DP table and path reconstruction

## Running Tests

```bash
python -m unittest discover -s tests -v
```

## Project Structure

```
dsa-explorer/
├── main.py                          # Entry point & main menu
├── requirements.txt
├── utils/
│   ├── colors.py                    # Color constants
│   └── ui.py                        # Shared UI components (Button, TextInput, InfoPanel)
├── modules/
│   ├── data_structures.py           # Phase 1
│   ├── sorting.py                   # Phase 2 — sorting
│   ├── graphs.py                    # Phase 2 — graph traversal
│   ├── heap.py                      # Phase 2 — heap
│   └── puzzles/
│       ├── puzzles_menu.py          # Phase 3 sub-menu
│       ├── pathfinding.py           # Pathfinding (Dijkstra / A*)
│       ├── event_queue.py           # Event queue simulator
│       └── dp_puzzle.py             # DP grid puzzle
└── tests/
    ├── test_data_structures.py      # 36 tests
    ├── test_sorting.py              # 21 tests
    ├── test_graphs.py               # 13 tests
    ├── test_heap.py                 # 10 tests
    └── test_puzzles.py              # 23 tests
```
