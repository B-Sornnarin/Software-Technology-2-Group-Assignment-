"""
Phase 3: Event Queue Simulator
==================================
Simulates a priority-based event processing system using a Min-Heap.
  - Events are scheduled with a priority value (lower = higher priority).
  - The heap always processes the highest-priority (lowest value) event first.
  - Demonstrates real-world use of heaps in OS scheduling, task management, etc.
Uses Python's heapq module for efficient O(log n) insert and extract operations.
"""

import pygame
import heapq
import random
from utils.colors import (
    WHITE, GRAY, DARK_GRAY, MODULE_BG,
    SUCCESS, DANGER, WARNING, ACCENT
)
from utils.ui import Button, draw_header, InfoPanel


# ---------------------------------------------------------------------------
# Event queue logic (no Pygame dependency)
# ---------------------------------------------------------------------------

class Event:
    """An event with a time and priority."""

    def __init__(self, name, time, priority):
        self.name = name
        self.time = time
        self.priority = priority

    def __lt__(self, other):
        if self.priority == other.priority:
            return self.time < other.time
        return self.priority < other.priority

    def __repr__(self):
        return f"Event({self.name}, t={self.time}, p={self.priority})"


class EventQueue:
    """Priority queue of events (min-heap by priority then time)."""

    def __init__(self):
        self.heap = []

    def schedule(self, event):
        heapq.heappush(self.heap, event)

    def process_next(self):
        if self.heap:
            return heapq.heappop(self.heap)
        return None

    def peek(self):
        return self.heap[0] if self.heap else None

    def size(self):
        return len(self.heap)

    def is_empty(self):
        return len(self.heap) == 0

    def to_list(self):
        return sorted(self.heap)


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

SAMPLE_NAMES = [
    "Login", "Logout", "Payment", "Upload", "Download",
    "Backup", "Alert", "Report", "Sync", "Notify",
    "Cleanup", "Deploy", "Audit", "Refresh", "Index",
]


def event_queue_module(screen, clock, width, height):
    """Event queue simulator visualization."""
    eq = EventQueue()
    processed = []

    add_rand_btn = Button(20, 65, 130, 35, "Add Random", SUCCESS, font_size=18)
    process_btn = Button(160, 65, 120, 35, "Process Next", DANGER, font_size=18)
    auto_btn = Button(290, 65, 80, 35, "Auto", ACCENT, font_size=18)
    clear_btn = Button(380, 65, 80, 35, "Clear", GRAY, font_size=18)
    bulk_btn = Button(470, 65, 110, 35, "Add 5 Rand", WARNING, font_size=18)
    info = InfoPanel(600, 55, 190, 220)
    info.set_title("Event Queue")

    auto_play = False
    auto_timer = 0
    next_time = 1

    font_sm = pygame.font.SysFont("Arial", 15)
    font_bold = pygame.font.SysFont("Arial", 18, bold=True)

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Event Queue Simulator", width)
        mouse = pygame.mouse.get_pos()
        for b in [add_rand_btn, process_btn, auto_btn, clear_btn, bulk_btn]:
            b.update(mouse)
            b.draw(screen)
        info.draw(screen)

        # Draw queued events as bars
        queued = eq.to_list()
        y_start = 120
        screen.blit(
            font_bold.render("Pending Events (sorted by priority):", True, DARK_GRAY),
            (20, y_start - 20))
        for i, ev in enumerate(queued[:12]):
            y = y_start + i * 32
            bar_w = max(60, min(350, ev.priority * 35 + 60))
            color_r = min(255, 50 + ev.priority * 25)
            color_g = max(0, 200 - ev.priority * 25)
            bar_color = (color_r, color_g, 100)
            pygame.draw.rect(screen, bar_color, (20, y, bar_w, 26), border_radius=4)
            pygame.draw.rect(screen, DARK_GRAY, (20, y, bar_w, 26), 1, border_radius=4)
            label = f"P{ev.priority} T{ev.time} {ev.name}"
            screen.blit(font_sm.render(label, True, WHITE), (28, y + 4))
        if len(queued) > 12:
            screen.blit(
                font_sm.render(f"... and {len(queued) - 12} more", True, GRAY),
                (20, y_start + 12 * 32))

        # Draw processed events
        proc_x = 420
        screen.blit(font_bold.render("Processed:", True, DARK_GRAY), (proc_x, y_start - 20))
        for i, ev in enumerate(processed[-10:]):
            y = y_start + i * 28
            label = f"{ev.name} (P{ev.priority}, T{ev.time})"
            screen.blit(font_sm.render(label, True, SUCCESS), (proc_x, y))

        # Footer info
        screen.blit(
            font_sm.render(f"Queue size: {eq.size()}  |  Processed: {len(processed)}",
                           True, DARK_GRAY), (20, height - 35))

        # Auto processing
        if auto_play and not eq.is_empty():
            auto_timer += 1
            if auto_timer >= 20:
                auto_timer = 0
                ev = eq.process_next()
                if ev:
                    processed.append(ev)
                    info.add_message(f"Processed: {ev.name}")
        elif auto_play and eq.is_empty():
            auto_play = False
            info.add_message("Queue empty, auto stopped")

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 13)
        screen.blit(instr_font.render(
            "HOW TO USE: Add Random events → PROCESS NEXT to handle one | AUTO to run all | RESET to clear | ESC to go back",
            True, DARK_GRAY), (20, height - 18))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if add_rand_btn.is_clicked(event.pos):
                    name = random.choice(SAMPLE_NAMES)
                    priority = random.randint(1, 8)
                    ev = Event(name, next_time, priority)
                    eq.schedule(ev)
                    next_time += 1
                    info.add_message(f"Scheduled: {name} P{priority}")
                elif bulk_btn.is_clicked(event.pos):
                    for _ in range(5):
                        name = random.choice(SAMPLE_NAMES)
                        priority = random.randint(1, 8)
                        ev = Event(name, next_time, priority)
                        eq.schedule(ev)
                        next_time += 1
                    info.add_message("Added 5 random events")
                elif process_btn.is_clicked(event.pos):
                    ev = eq.process_next()
                    if ev:
                        processed.append(ev)
                        info.add_message(f"Processed: {ev.name}")
                    else:
                        info.add_message("Queue is empty!")
                elif auto_btn.is_clicked(event.pos):
                    auto_play = not auto_play
                    auto_timer = 0
                    info.add_message("Auto " + ("ON" if auto_play else "OFF"))
                elif clear_btn.is_clicked(event.pos):
                    eq = EventQueue()
                    processed.clear()
                    next_time = 1
                    auto_play = False
                    info.add_message("Cleared all")
        clock.tick(30)
