"""
Phase 3: Dynamic Programming Puzzle
========================================
Grid path counting problem solved using Dynamic Programming (DP).
  - Goal    : Count number of unique paths from top-left to bottom-right.
  - Rules   : Can only move right or down. Walls block movement.
  - DP logic: dp[r][c] = dp[r-1][c] + dp[r][c-1] (paths from top + paths from left)
  - Time    : O(rows * cols) | Space: O(rows * cols)
Visualizes the DP table being filled cell by cell and reconstructs the path.
"""

import pygame
from utils.colors import (
    WHITE, GRAY, DARK_GRAY, PRIMARY, MODULE_BG,
    SUCCESS, DANGER, WARNING, GRID_WALL, GRID_PATH, GRID_START,
    GRID_END
)
from utils.ui import Button, draw_header, InfoPanel


# ---------------------------------------------------------------------------
# DP logic (no Pygame dependency)
# ---------------------------------------------------------------------------

def count_paths(grid):
    """Count unique paths from top-left to bottom-right.
    Returns (dp_table, total_paths). grid[r][c]==1 is an obstacle.
    """
    rows = len(grid)
    cols = len(grid[0]) if rows else 0
    dp = [[0] * cols for _ in range(rows)]
    if grid[0][0] == 1 or grid[rows - 1][cols - 1] == 1:
        return dp, 0
    dp[0][0] = 1
    for r in range(rows):
        for c in range(cols):
            if r == 0 and c == 0:
                continue
            if grid[r][c] == 1:
                dp[r][c] = 0
            else:
                top = dp[r - 1][c] if r > 0 else 0
                left = dp[r][c - 1] if c > 0 else 0
                dp[r][c] = top + left
    return dp, dp[rows - 1][cols - 1]


def reconstruct_path(dp, grid):
    """Reconstruct one valid path from bottom-right back to top-left."""
    rows = len(dp)
    cols = len(dp[0]) if rows else 0
    if dp[rows - 1][cols - 1] == 0:
        return []
    path = []
    r, c = rows - 1, cols - 1
    path.append((r, c))
    while (r, c) != (0, 0):
        top = dp[r - 1][c] if r > 0 else 0
        left = dp[r][c - 1] if c > 0 else 0
        if r > 0 and top > 0:
            r -= 1
        elif c > 0 and left > 0:
            c -= 1
        else:
            break
        path.append((r, c))
    path.reverse()
    return path


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

DP_ROWS, DP_COLS = 12, 16
CELL = 36


def dp_puzzle_module(screen, clock, width, height):
    """DP grid puzzle visualization."""
    grid = [[0] * DP_COLS for _ in range(DP_ROWS)]
    dp_table = None
    path = []
    total_paths = 0
    grid_x, grid_y = 30, 120

    solve_btn = Button(20, 65, 80, 35, "Solve", SUCCESS, font_size=20)
    clear_path_btn = Button(110, 65, 110, 35, "Clear Path", WARNING, font_size=18)
    clear_all_btn = Button(230, 65, 100, 35, "Clear All", DANGER, font_size=18)
    info = InfoPanel(580, 55, 210, 200)
    info.set_title("DP Puzzle")

    painting = None
    show_dp = False
    show_dp_btn = Button(340, 65, 120, 35, "Show DP", PRIMARY, font_size=18)
    anim_step = 0
    animating = False

    font = pygame.font.SysFont("Arial", 14)
    font_lg = pygame.font.SysFont("Arial", 18)

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "DP Grid Path Counter", width)
        mouse = pygame.mouse.get_pos()
        for b in [solve_btn, clear_path_btn, clear_all_btn, show_dp_btn]:
            b.update(mouse)
            b.draw(screen)
        info.draw(screen)

        # Draw grid
        for r in range(DP_ROWS):
            for c in range(DP_COLS):
                x = grid_x + c * CELL
                y = grid_y + r * CELL
                rect = pygame.Rect(x, y, CELL, CELL)

                if (r, c) == (0, 0):
                    color = GRID_START
                elif (r, c) == (DP_ROWS - 1, DP_COLS - 1):
                    color = GRID_END
                elif (r, c) in path[:anim_step if animating else len(path)]:
                    color = GRID_PATH
                elif dp_table and dp_table[r][c] > 0 and show_dp and grid[r][c] == 0:
                    # Shade by dp value
                    intensity = min(255, 180 + dp_table[r][c] * 2)
                    color = (200, 220, intensity)
                elif grid[r][c] == 1:
                    color = GRID_WALL
                else:
                    color = WHITE

                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, GRAY, rect, 1)

                # Show DP values
                if show_dp and dp_table and grid[r][c] == 0:
                    val = dp_table[r][c]
                    if val > 0:
                        t = font.render(str(val), True, DARK_GRAY)
                        screen.blit(t, (x + CELL // 2 - t.get_width() // 2,
                                        y + CELL // 2 - t.get_height() // 2))

        # Arrows on path
        if not animating and path:
            screen.blit(font_lg.render("S", True, WHITE),
                        (grid_x + 12, grid_y + 8))
            ex = grid_x + (DP_COLS - 1) * CELL + 10
            ey = grid_y + (DP_ROWS - 1) * CELL + 8
            screen.blit(font_lg.render("E", True, WHITE), (ex, ey))

        # Animate
        if animating:
            anim_step += 1
            if anim_step > len(path):
                animating = False

        # Footer
        screen.blit(font_lg.render(
            f"Total unique paths: {total_paths}   |   Click to place/remove walls",
            True, DARK_GRAY), (20, height - 35))

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 13)
        screen.blit(instr_font.render(
            "HOW TO USE: Click grid cells to add/remove walls → SOLVE to count paths & animate → RESET to clear | ESC to go back",
            True, DARK_GRAY), (20, height - 18))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if solve_btn.is_clicked(event.pos):
                    dp_table, total_paths = count_paths(grid)
                    path = reconstruct_path(dp_table, grid)
                    anim_step = 0
                    animating = True
                    show_dp = True
                    info.add_message(f"Paths: {total_paths}")
                    if path:
                        info.add_message(f"Path len: {len(path)}")
                    else:
                        info.add_message("No path exists!")
                elif clear_path_btn.is_clicked(event.pos):
                    dp_table = None
                    path = []
                    total_paths = 0
                    show_dp = False
                    animating = False
                    info.add_message("Path cleared")
                elif clear_all_btn.is_clicked(event.pos):
                    grid = [[0] * DP_COLS for _ in range(DP_ROWS)]
                    dp_table = None
                    path = []
                    total_paths = 0
                    show_dp = False
                    animating = False
                    info.add_message("Grid cleared")
                elif show_dp_btn.is_clicked(event.pos):
                    show_dp = not show_dp
                    info.add_message("DP " + ("shown" if show_dp else "hidden"))
                else:
                    gx = (event.pos[0] - grid_x) // CELL
                    gy = (event.pos[1] - grid_y) // CELL
                    if 0 <= gx < DP_COLS and 0 <= gy < DP_ROWS:
                        if (gy, gx) != (0, 0) and (gy, gx) != (DP_ROWS - 1, DP_COLS - 1):
                            painting = "wall" if grid[gy][gx] == 0 else "clear"
                            grid[gy][gx] = 1 if painting == "wall" else 0

            if event.type == pygame.MOUSEMOTION and pygame.mouse.get_pressed()[0]:
                if painting:
                    gx = (event.pos[0] - grid_x) // CELL
                    gy = (event.pos[1] - grid_y) // CELL
                    if 0 <= gx < DP_COLS and 0 <= gy < DP_ROWS:
                        if (gy, gx) != (0, 0) and (gy, gx) != (DP_ROWS - 1, DP_COLS - 1):
                            grid[gy][gx] = 1 if painting == "wall" else 0

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                painting = None

        clock.tick(30)
