"""Phase 3: Puzzle Challenges - sub-menu for pathfinding, event queue, DP puzzle."""

import pygame
from utils.colors import (
    MODULE_BG, SUCCESS, WARNING, ACCENT
)
from utils.ui import Button, draw_header
from modules.puzzles.pathfinding import pathfinding_module
from modules.puzzles.event_queue import event_queue_module
from modules.puzzles.dp_puzzle import dp_puzzle_module


def puzzles_module(screen, clock, width, height):
    """Entry point for Phase 3 puzzle challenges."""
    buttons = [
        Button(width // 2 - 140, 180, 280, 55, "Pathfinding Puzzle", SUCCESS, font_size=22),
        Button(width // 2 - 140, 260, 280, 55, "Event Queue Simulator", ACCENT, font_size=22),
        Button(width // 2 - 140, 340, 280, 55, "DP Grid Puzzle", WARNING, font_size=22),
    ]
    handlers = [pathfinding_module, event_queue_module, dp_puzzle_module]

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Puzzle Challenges", width)
        mouse = pygame.mouse.get_pos()
        for b in buttons:
            b.update(mouse)
            b.draw(screen)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i, b in enumerate(buttons):
                    if b.is_clicked(event.pos):
                        result = handlers[i](screen, clock, width, height)
                        if result is None:
                            return None
                        # "back" returns to this sub-menu
        clock.tick(30)
