"""
Phase 3: Pathfinding Puzzle
==============================
Interactive grid-based pathfinding using two algorithms:
  - Dijkstra's Algorithm: Finds shortest path by expanding lowest-cost node first.
                          Uses a min-heap (priority queue). O((V+E) log V)
  - A* Algorithm        : Like Dijkstra but uses a heuristic (Manhattan distance)
                          to guide search toward the goal faster. O((V+E) log V)
Users can place walls, set start/end points, and watch the algorithm find the path.
"""

import pygame
import heapq
from utils.colors import (
    GRAY, DARK_GRAY, PRIMARY, MODULE_BG,
    GRID_EMPTY, GRID_WALL, GRID_START, GRID_END, GRID_PATH, GRID_EXPLORED,
    SUCCESS, DANGER, WARNING
)
from utils.ui import Button, draw_header, InfoPanel


# ---------------------------------------------------------------------------
# Pathfinding logic (no Pygame dependency)
# ---------------------------------------------------------------------------

def dijkstra(grid, start, end):
    """Run Dijkstra on a 2-D grid. Returns (path, explored_order).
    grid[r][c] == 1 means wall. Movement: 4-directional, cost 1 each.
    """
    rows, cols = len(grid), len(grid[0])
    dist = {start: 0}
    prev = {}
    explored = []
    pq = [(0, start)]

    while pq:
        d, node = heapq.heappop(pq)
        if d > dist.get(node, float("inf")):
            continue
        explored.append(node)
        if node == end:
            break
        r, c = node
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 0:
                nd = d + 1
                if nd < dist.get((nr, nc), float("inf")):
                    dist[(nr, nc)] = nd
                    prev[(nr, nc)] = node
                    heapq.heappush(pq, (nd, (nr, nc)))

    # Reconstruct path
    path = []
    cur = end
    while cur in prev:
        path.append(cur)
        cur = prev[cur]
    if cur == start:
        path.append(start)
        path.reverse()
    else:
        path = []
    return path, explored


def astar(grid, start, end):
    """Run A* on a 2-D grid. Returns (path, explored_order)."""
    rows, cols = len(grid), len(grid[0])
    if grid[start[0]][start[1]] == 1 or grid[end[0]][end[1]] == 1:
        return [], []

    def heuristic(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    g_score = {start: 0}
    f_score = {start: heuristic(start, end)}
    prev = {}
    explored = []
    pq = [(f_score[start], start)]
    closed = set()

    while pq:
        _, node = heapq.heappop(pq)
        if node in closed:
            continue
        closed.add(node)
        explored.append(node)
        if node == end:
            break
        r, c = node
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 0:
                tentative_g = g_score[node] + 1
                if tentative_g < g_score.get((nr, nc), float("inf")):
                    g_score[(nr, nc)] = tentative_g
                    f = tentative_g + heuristic((nr, nc), end)
                    f_score[(nr, nc)] = f
                    prev[(nr, nc)] = node
                    heapq.heappush(pq, (f, (nr, nc)))

    path = []
    cur = end
    while cur in prev:
        path.append(cur)
        cur = prev[cur]
    if cur == start:
        path.append(start)
        path.reverse()
    else:
        path = []
    return path, explored


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

ROWS, COLS = 25, 35
CELL_SIZE = 20

def pathfinding_module(screen, clock, width, height):
    """Pathfinding puzzle module."""
    grid = [[0] * COLS for _ in range(ROWS)]
    start = (2, 2)
    end = (ROWS - 3, COLS - 3)
    grid_offset_x = 20
    grid_offset_y = 110

    algo_name = "A*"
    dijkstra_btn = Button(20, 60, 100, 35, "Dijkstra", PRIMARY, font_size=18)
    astar_btn = Button(130, 60, 80, 35, "A*", PRIMARY, font_size=18)
    run_btn = Button(220, 60, 80, 35, "Run", SUCCESS, font_size=20)
    clear_path_btn = Button(310, 60, 110, 35, "Clear Path", WARNING, font_size=18)
    clear_all_btn = Button(430, 60, 100, 35, "Clear All", DANGER, font_size=18)
    info = InfoPanel(560, 55, 230, 160)
    info.set_title("Pathfinding Puzzle")

    explored_cells = []
    path_cells = []
    anim_idx = 0
    animating = False
    anim_phase = "explore"  # "explore" then "path"
    painting = None  # "wall" or "clear"
    setting_mode = None  # "start" or "end"

    set_start_btn = Button(20, height - 40, 100, 30, "Set Start", GRID_START, font_size=16)
    set_end_btn = Button(130, height - 40, 100, 30, "Set End", DANGER, font_size=16)

    font_sm = pygame.font.SysFont("Arial", 14)

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, f"Pathfinding Puzzle — {algo_name}", width)
        mouse = pygame.mouse.get_pos()
        for b in [dijkstra_btn, astar_btn, run_btn, clear_path_btn,
                  clear_all_btn, set_start_btn, set_end_btn]:
            b.update(mouse)
            b.draw(screen)
        info.draw(screen)

        # Draw grid
        for r in range(ROWS):
            for c in range(COLS):
                x = grid_offset_x + c * CELL_SIZE
                y = grid_offset_y + r * CELL_SIZE
                rect = pygame.Rect(x, y, CELL_SIZE, CELL_SIZE)
                if (r, c) == start:
                    color = GRID_START
                elif (r, c) == end:
                    color = GRID_END
                elif (r, c) in path_cells[:anim_idx if anim_phase == "path" else len(path_cells)]:
                    if not animating or anim_phase == "path":
                        color = GRID_PATH
                    else:
                        color = GRID_EXPLORED
                elif (r, c) in explored_cells[:anim_idx if anim_phase == "explore" else len(explored_cells)]:
                    color = GRID_EXPLORED
                elif grid[r][c] == 1:
                    color = GRID_WALL
                else:
                    color = GRID_EMPTY
                pygame.draw.rect(screen, color, rect)
                pygame.draw.rect(screen, GRAY, rect, 1)

        # Animate
        if animating:
            anim_idx += 3
            if anim_phase == "explore":
                if anim_idx >= len(explored_cells):
                    anim_idx = 0
                    anim_phase = "path"
                    if not path_cells:
                        animating = False
                        info.add_message("No path found!")
            elif anim_phase == "path":
                if anim_idx >= len(path_cells):
                    animating = False
                    info.add_message(f"Path length: {len(path_cells)}")

        # Mode label
        if setting_mode:
            screen.blit(font_sm.render(f"Click grid to set {setting_mode}", True, DANGER),
                        (250, height - 35))

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 13)
        screen.blit(instr_font.render(
            "HOW TO USE: Set Start/End → Click grid to place walls → Choose Dijkstra or A* → RUN | ESC to go back",
            True, DARK_GRAY), (20, height - 18))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if dijkstra_btn.is_clicked(event.pos):
                    algo_name = "Dijkstra"
                    info.add_message("Algorithm: Dijkstra")
                elif astar_btn.is_clicked(event.pos):
                    algo_name = "A*"
                    info.add_message("Algorithm: A*")
                elif run_btn.is_clicked(event.pos) and not animating:
                    func = astar if algo_name == "A*" else dijkstra
                    path_cells_result, explored_result = func(grid, start, end)
                    explored_cells = explored_result
                    path_cells = path_cells_result
                    anim_idx = 0
                    anim_phase = "explore"
                    animating = True
                    info.add_message(f"Running {algo_name}...")
                elif clear_path_btn.is_clicked(event.pos):
                    explored_cells = []
                    path_cells = []
                    animating = False
                    info.add_message("Path cleared")
                elif clear_all_btn.is_clicked(event.pos):
                    grid = [[0] * COLS for _ in range(ROWS)]
                    explored_cells = []
                    path_cells = []
                    animating = False
                    info.add_message("Grid cleared")
                elif set_start_btn.is_clicked(event.pos):
                    setting_mode = "start"
                elif set_end_btn.is_clicked(event.pos):
                    setting_mode = "end"
                else:
                    # Grid interaction
                    gx = (event.pos[0] - grid_offset_x) // CELL_SIZE
                    gy = (event.pos[1] - grid_offset_y) // CELL_SIZE
                    if 0 <= gx < COLS and 0 <= gy < ROWS:
                        if setting_mode == "start":
                            if grid[gy][gx] == 0:
                                start = (gy, gx)
                                info.add_message(f"Start: ({gy},{gx})")
                            setting_mode = None
                        elif setting_mode == "end":
                            if grid[gy][gx] == 0:
                                end = (gy, gx)
                                info.add_message(f"End: ({gy},{gx})")
                            setting_mode = None
                        else:
                            if (gy, gx) != start and (gy, gx) != end:
                                painting = "wall" if grid[gy][gx] == 0 else "clear"
                                grid[gy][gx] = 1 if painting == "wall" else 0

            if event.type == pygame.MOUSEMOTION and pygame.mouse.get_pressed()[0]:
                if painting and not animating and setting_mode is None:
                    gx = (event.pos[0] - grid_offset_x) // CELL_SIZE
                    gy = (event.pos[1] - grid_offset_y) // CELL_SIZE
                    if 0 <= gx < COLS and 0 <= gy < ROWS:
                        if (gy, gx) != start and (gy, gx) != end:
                            grid[gy][gx] = 1 if painting == "wall" else 0

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                painting = None

        clock.tick(30)
