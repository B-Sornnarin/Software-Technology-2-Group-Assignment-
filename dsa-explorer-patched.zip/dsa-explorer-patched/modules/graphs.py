"""
Phase 2: Graph Traversal Visualizer
======================================
Implements and visualizes two graph traversal algorithms:
  - BFS (Breadth-First Search): Explores level by level using a queue. O(V+E)
  - DFS (Depth-First Search) : Explores as deep as possible using a stack. O(V+E)
Users can add nodes/edges interactively and select the start node.
"""

import pygame
import math
import collections
from utils.colors import (
    WHITE, GRAY, DARK_GRAY, PRIMARY, MODULE_BG,
    NODE_DEFAULT, NODE_VISITED, NODE_CURRENT, NODE_START,
    EDGE_DEFAULT, EDGE_VISITED, SUCCESS, DANGER, WARNING, ACCENT
)
from utils.ui import Button, draw_header, InfoPanel


# ---------------------------------------------------------------------------
# Graph logic (no Pygame dependency)
# ---------------------------------------------------------------------------

class Graph:
    """
    Undirected graph using an adjacency list (dictionary of sets).
    Supports adding/removing nodes and edges, BFS, and DFS.
    V = number of vertices, E = number of edges.
    Space complexity: O(V + E).
    """

    def __init__(self):
        self.adj = {}  # node_id -> set of neighbor ids

    def add_node(self, node_id):
        """Add a node to the graph if it doesn't already exist."""
        if node_id not in self.adj:
            self.adj[node_id] = set()

    def add_edge(self, u, v):
        """Add an undirected edge between nodes u and v."""
        self.add_node(u)
        self.add_node(v)
        self.adj[u].add(v)
        self.adj[v].add(u)  # Undirected: add both directions

    def remove_node(self, node_id):
        """Remove a node and all its edges from the graph."""
        if node_id in self.adj:
            for nb in list(self.adj[node_id]):
                self.adj[nb].discard(node_id)  # Remove from neighbors
            del self.adj[node_id]

    def neighbors(self, node_id):
        """Return sorted list of neighbors for a given node."""
        return sorted(self.adj.get(node_id, set()))

    def nodes(self):
        """Return list of all node IDs in the graph."""
        return list(self.adj.keys())

    def edges(self):
        """Return list of unique edges as (u, v) tuples."""
        seen = set()
        result = []
        for u in self.adj:
            for v in self.adj[u]:
                edge = (min(u, v), max(u, v))  # Normalize to avoid duplicates
                if edge not in seen:
                    seen.add(edge)
                    result.append(edge)
        return result

    def bfs_steps(self, start):
        """
        BFS generator for step-by-step visualization.
        Uses a queue (deque). Explores all neighbors before going deeper.
        Yields (current_node, visited_set, queue_list) at each step.
        """
        if start not in self.adj:
            return
        visited = set()
        queue = collections.deque([start])
        visited.add(start)
        while queue:
            node = queue.popleft()  # Dequeue from front
            yield node, set(visited), list(queue)
            for nb in self.neighbors(node):
                if nb not in visited:
                    visited.add(nb)
                    queue.append(nb)  # Enqueue unvisited neighbors
        yield None, visited, []  # Signal traversal complete

    def dfs_steps(self, start):
        """
        DFS generator for step-by-step visualization.
        Uses a stack. Explores as deep as possible before backtracking.
        Yields (current_node, visited_set, stack_list) at each step.
        """
        if start not in self.adj:
            return
        visited = set()
        stack = [start]
        while stack:
            node = stack.pop()  # Pop from top of stack
            if node in visited:
                continue
            visited.add(node)
            yield node, set(visited), list(stack)
            for nb in reversed(self.neighbors(node)):
                if nb not in visited:
                    stack.append(nb)  # Push unvisited neighbors
        yield None, visited, []  # Signal traversal complete

    def bfs(self, start):
        """Run full BFS and return visit order as a list."""
        if start not in self.adj:
            return []
        visited = set()
        queue = collections.deque([start])
        visited.add(start)
        order = []
        while queue:
            node = queue.popleft()
            order.append(node)
            for nb in self.neighbors(node):
                if nb not in visited:
                    visited.add(nb)
                    queue.append(nb)
        return order

    def dfs(self, start):
        """Run full DFS and return visit order as a list."""
        if start not in self.adj:
            return []
        visited = set()
        stack = [start]
        order = []
        while stack:
            node = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            order.append(node)
            for nb in reversed(self.neighbors(node)):
                if nb not in visited:
                    stack.append(nb)
        return order


# ---------------------------------------------------------------------------
# Default sample graph positions
# ---------------------------------------------------------------------------

def _default_graph():
    g = Graph()
    positions = {}
    nodes = list(range(8))
    cx, cy = 400, 330
    radius = 160
    for i, n in enumerate(nodes):
        angle = 2 * math.pi * i / len(nodes) - math.pi / 2
        px = int(cx + radius * math.cos(angle))
        py = int(cy + radius * math.sin(angle))
        g.add_node(n)
        positions[n] = (px, py)
    edges = [(0, 1), (0, 7), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7),
             (0, 3), (1, 5), (2, 6)]
    for u, v in edges:
        g.add_edge(u, v)
    return g, positions


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

def graphs_module(screen, clock, width, height):
    """Graph BFS/DFS visualization module."""
    graph, positions = _default_graph()
    next_id = max(graph.nodes()) + 1

    bfs_btn = Button(20, 60, 80, 35, "BFS", SUCCESS, font_size=20)
    dfs_btn = Button(110, 60, 80, 35, "DFS", WARNING, font_size=20)
    step_btn = Button(200, 60, 80, 35, "Step", PRIMARY, font_size=20)
    auto_btn = Button(290, 60, 80, 35, "Auto", ACCENT, font_size=20)
    reset_btn = Button(380, 60, 80, 35, "Reset", DANGER, font_size=20)
    clear_btn = Button(470, 60, 100, 35, "Clear All", GRAY, font_size=18)
    info = InfoPanel(590, 55, 200, 180)
    info.set_title("Graph Traversal")

    instructions_font = pygame.font.SysFont("Arial", 14)
    instr_lines = [
        "HOW TO USE:",
        "• Left-click empty space = add node",
        "• Drag node to node = add edge",
        "• Right-click node = set start",
        "• BFS/DFS → STEP or AUTO to traverse",
        "• ESC = return to menu",
    ]

    selected_start = 0
    traversal_gen = None
    traversal_type = "bfs"
    current_node = None
    visited = set()
    auto_play = False
    auto_timer = 0
    dragging_from = None

    NODE_RADIUS = 22

    def node_at(pos):
        for nid, (nx, ny) in positions.items():
            if math.hypot(pos[0] - nx, pos[1] - ny) <= NODE_RADIUS:
                return nid
        return None

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Graph Traversal (BFS / DFS)", width)
        mouse = pygame.mouse.get_pos()
        for b in [bfs_btn, dfs_btn, step_btn, auto_btn, reset_btn, clear_btn]:
            b.update(mouse)
            b.draw(screen)
        info.draw(screen)

        # Instructions
        for i, line in enumerate(instr_lines):
            screen.blit(instructions_font.render(line, True, DARK_GRAY), (20, height - 80 + i * 18))

        # Draw edges
        for u, v in graph.edges():
            pu, pv = positions[u], positions[v]
            ecolor = EDGE_VISITED if (u in visited and v in visited) else EDGE_DEFAULT
            pygame.draw.line(screen, ecolor, pu, pv, 3)

        # Draw nodes
        for nid in graph.nodes():
            px, py = positions[nid]
            if nid == current_node:
                color = NODE_CURRENT
            elif nid in visited:
                color = NODE_VISITED
            elif nid == selected_start:
                color = NODE_START
            else:
                color = NODE_DEFAULT
            pygame.draw.circle(screen, color, (px, py), NODE_RADIUS)
            pygame.draw.circle(screen, DARK_GRAY, (px, py), NODE_RADIUS, 2)
            font = pygame.font.SysFont("Arial", 18, bold=True)
            t = font.render(str(nid), True, WHITE)
            screen.blit(t, (px - t.get_width() // 2, py - t.get_height() // 2))

        # Drag line
        if dragging_from is not None:
            px, py = positions[dragging_from]
            pygame.draw.line(screen, ACCENT, (px, py), mouse, 2)

        # Auto step
        if auto_play and traversal_gen:
            auto_timer += 1
            if auto_timer >= 15:
                auto_timer = 0
                try:
                    current_node, visited, _ = next(traversal_gen)
                    if current_node is not None:
                        info.add_message(f"Visit node {current_node}")
                    else:
                        info.add_message("Traversal complete!")
                        auto_play = False
                except StopIteration:
                    auto_play = False

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    # UI buttons
                    if bfs_btn.is_clicked(event.pos):
                        traversal_type = "bfs"
                        info.add_message("Mode: BFS")
                    elif dfs_btn.is_clicked(event.pos):
                        traversal_type = "dfs"
                        info.add_message("Mode: DFS")
                    elif step_btn.is_clicked(event.pos):
                        if traversal_gen is None:
                            if traversal_type == "bfs":
                                traversal_gen = graph.bfs_steps(selected_start)
                            else:
                                traversal_gen = graph.dfs_steps(selected_start)
                            info.add_message(f"Started {traversal_type.upper()} from {selected_start}")
                        try:
                            current_node, visited, _ = next(traversal_gen)
                            if current_node is not None:
                                info.add_message(f"Visit node {current_node}")
                            else:
                                info.add_message("Done!")
                                traversal_gen = None
                        except StopIteration:
                            traversal_gen = None
                    elif auto_btn.is_clicked(event.pos):
                        if traversal_gen is None:
                            if traversal_type == "bfs":
                                traversal_gen = graph.bfs_steps(selected_start)
                            else:
                                traversal_gen = graph.dfs_steps(selected_start)
                        auto_play = not auto_play
                        info.add_message("Auto " + ("ON" if auto_play else "OFF"))
                    elif reset_btn.is_clicked(event.pos):
                        traversal_gen = None
                        current_node = None
                        visited = set()
                        auto_play = False
                        info.add_message("Reset traversal")
                    elif clear_btn.is_clicked(event.pos):
                        graph, positions = _default_graph()
                        next_id = max(graph.nodes()) + 1
                        traversal_gen = None
                        current_node = None
                        visited = set()
                        auto_play = False
                        selected_start = 0
                        info.add_message("Graph reset")
                    else:
                        # Check if clicking on a node (start drag)
                        nid = node_at(event.pos)
                        if nid is not None:
                            dragging_from = nid
                        else:
                            # Add node at position if in graph area
                            if event.pos[1] > 100 and event.pos[1] < height - 90:
                                graph.add_node(next_id)
                                positions[next_id] = event.pos
                                info.add_message(f"Added node {next_id}")
                                next_id += 1
                elif event.button == 3:  # Right click
                    nid = node_at(event.pos)
                    if nid is not None:
                        selected_start = nid
                        info.add_message(f"Start node: {nid}")
                        traversal_gen = None
                        current_node = None
                        visited = set()
                        auto_play = False

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if dragging_from is not None:
                    target = node_at(event.pos)
                    if target is not None and target != dragging_from:
                        graph.add_edge(dragging_from, target)
                        info.add_message(f"Edge {dragging_from}-{target}")
                    dragging_from = None

        clock.tick(30)
