"""Color constants used throughout the DSA Explorer app."""

# Basic colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (180, 180, 180)
DARK_GRAY = (100, 100, 100)
LIGHT_GRAY = (220, 220, 220)

# Primary palette
PRIMARY = (70, 130, 180)       # Steel blue
PRIMARY_DARK = (50, 100, 150)
PRIMARY_LIGHT = (140, 180, 210)
ACCENT = (255, 165, 0)         # Orange
ACCENT_DARK = (220, 140, 0)

# Status colors
SUCCESS = (46, 204, 113)       # Green
DANGER = (231, 76, 60)         # Red
WARNING = (241, 196, 15)       # Yellow
INFO = (52, 152, 219)          # Blue

# Data structure colors
STACK_COLOR = (155, 89, 182)   # Purple
QUEUE_COLOR = (26, 188, 156)   # Teal
LINKED_LIST_COLOR = (52, 152, 219)  # Blue
BST_COLOR = (230, 126, 34)    # Orange

# Sorting colors
BAR_DEFAULT = (52, 152, 219)
BAR_COMPARE = (231, 76, 60)
BAR_SORTED = (46, 204, 113)
BAR_SWAP = (241, 196, 15)

# Graph colors
NODE_DEFAULT = (52, 152, 219)
NODE_VISITED = (46, 204, 113)
NODE_CURRENT = (231, 76, 60)
NODE_START = (255, 165, 0)
EDGE_DEFAULT = (180, 180, 180)
EDGE_VISITED = (46, 204, 113)

# Puzzle colors
GRID_EMPTY = (255, 255, 255)
GRID_WALL = (44, 62, 80)
GRID_START = (46, 204, 113)
GRID_END = (231, 76, 60)
GRID_PATH = (241, 196, 15)
GRID_EXPLORED = (174, 214, 241)

# Background
BG_COLOR = (240, 244, 248)
MENU_BG = (200, 210, 230)
MODULE_BG = (245, 248, 252)
