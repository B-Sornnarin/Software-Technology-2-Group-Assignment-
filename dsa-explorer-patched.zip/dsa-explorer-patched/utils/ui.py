"""Common UI components for the DSA Explorer app."""

import pygame
from utils.colors import (
    WHITE, BLACK, GRAY, DARK_GRAY, PRIMARY, PRIMARY_DARK,
    PRIMARY_LIGHT
)


class Button:
    """A clickable button with hover effects."""

    def __init__(self, x, y, width, height, text, color=PRIMARY,
                 hover_color=PRIMARY_DARK, text_color=WHITE, font_size=24):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.text_color = text_color
        self.font = pygame.font.SysFont("Arial", font_size)
        self.hovered = False

    def draw(self, screen):
        color = self.hover_color if self.hovered else self.color
        pygame.draw.rect(screen, color, self.rect, border_radius=8)
        pygame.draw.rect(screen, DARK_GRAY, self.rect, 2, border_radius=8)
        txt_surf = self.font.render(self.text, True, self.text_color)
        txt_rect = txt_surf.get_rect(center=self.rect.center)
        screen.blit(txt_surf, txt_rect)

    def update(self, mouse_pos):
        self.hovered = self.rect.collidepoint(mouse_pos)

    def is_clicked(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)


class TextInput:
    """A simple text input field."""

    def __init__(self, x, y, width, height, placeholder="", font_size=22):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = ""
        self.placeholder = placeholder
        self.font = pygame.font.SysFont("Arial", font_size)
        self.active = False

    def draw(self, screen):
        border_color = PRIMARY if self.active else GRAY
        pygame.draw.rect(screen, WHITE, self.rect, border_radius=4)
        pygame.draw.rect(screen, border_color, self.rect, 2, border_radius=4)
        if self.text:
            txt_surf = self.font.render(self.text, True, BLACK)
        else:
            txt_surf = self.font.render(self.placeholder, True, GRAY)
        screen.blit(txt_surf, (self.rect.x + 8, self.rect.y + 6))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)
        if event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif event.key == pygame.K_RETURN:
                return self.text
            else:
                if len(self.text) < 10:
                    self.text += event.unicode
        return None

    def get_value(self):
        try:
            return int(self.text)
        except ValueError:
            return None

    def clear(self):
        self.text = ""


class InfoPanel:
    """Display algorithm info and status messages."""

    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.messages = []
        self.font = pygame.font.SysFont("Arial", 18)
        self.title_font = pygame.font.SysFont("Arial", 22, bold=True)
        self.title = ""

    def set_title(self, title):
        self.title = title

    def add_message(self, msg):
        self.messages.append(msg)
        if len(self.messages) > 8:
            self.messages.pop(0)

    def clear(self):
        self.messages.clear()

    def draw(self, screen):
        pygame.draw.rect(screen, WHITE, self.rect, border_radius=6)
        pygame.draw.rect(screen, GRAY, self.rect, 1, border_radius=6)
        y = self.rect.y + 8
        if self.title:
            t = self.title_font.render(self.title, True, PRIMARY_DARK)
            screen.blit(t, (self.rect.x + 10, y))
            y += 28
        for msg in self.messages:
            t = self.font.render(msg, True, DARK_GRAY)
            screen.blit(t, (self.rect.x + 10, y))
            y += 22


def draw_header(screen, title, width):
    """Draw a module header bar with back button hint."""
    header_rect = pygame.Rect(0, 0, width, 50)
    pygame.draw.rect(screen, PRIMARY, header_rect)
    font = pygame.font.SysFont("Arial", 28, bold=True)
    txt = font.render(title, True, WHITE)
    screen.blit(txt, (width // 2 - txt.get_width() // 2, 10))
    small_font = pygame.font.SysFont("Arial", 16)
    back_txt = small_font.render("Press ESC to return to menu", True, PRIMARY_LIGHT)
    screen.blit(back_txt, (10, 15))


def draw_instructions(screen, instructions, x, y, font_size=16):
    """Draw a list of instruction strings."""
    font = pygame.font.SysFont("Arial", font_size)
    for i, line in enumerate(instructions):
        txt = font.render(line, True, DARK_GRAY)
        screen.blit(txt, (x, y + i * 20))
