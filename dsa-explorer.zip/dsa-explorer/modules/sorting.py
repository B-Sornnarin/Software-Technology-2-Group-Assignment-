"""
Phase 2: Sorting Algorithm Visualizer
========================================
Implements and visualizes three sorting algorithms:
  - Bubble Sort   : Compare adjacent pairs, swap if out of order. O(n²)
  - Selection Sort: Find minimum element, place it at correct position. O(n²)
  - Merge Sort    : Divide array in half, sort each half, merge. O(n log n)
Each algorithm uses a generator for step-by-step PyGame visualization.
"""

import random
try:
    import pygame
    from utils.colors import (
        DARK_GRAY, PRIMARY, MODULE_BG,
        BAR_DEFAULT, BAR_COMPARE, BAR_SORTED, SUCCESS, DANGER, WARNING
    )
    from utils.ui import Button, draw_header, InfoPanel
    _PYGAME_AVAILABLE = True
except ImportError:
    _PYGAME_AVAILABLE = False


# ---------------------------------------------------------------------------
# Sorting algorithms (generator-based for step-by-step visualization)
# ---------------------------------------------------------------------------

def bubble_sort_steps(arr):
    """
    Bubble Sort generator for visualization.
    Repeatedly compares adjacent elements and swaps if left > right.
    Largest unsorted element 'bubbles up' to its correct position each pass.
    Time: O(n²) | Space: O(1)
    Yields (array_copy, compare_indices, sorted_indices) at each step.
    """
    n = len(arr)
    sorted_indices = set()
    for i in range(n):
        for j in range(0, n - i - 1):
            yield list(arr), (j, j + 1), sorted_indices.copy()  # Highlight comparison
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]         # Swap if out of order
                yield list(arr), (j, j + 1), sorted_indices.copy()
        sorted_indices.add(n - i - 1)  # Last element of this pass is now sorted
    sorted_indices = set(range(n))
    yield list(arr), (-1, -1), sorted_indices


def selection_sort_steps(arr):
    """
    Selection Sort generator for visualization.
    Finds the minimum element in unsorted portion and places it at front.
    Time: O(n²) | Space: O(1)
    Yields (array_copy, compare_indices, sorted_indices) at each step.
    """
    n = len(arr)
    sorted_indices = set()
    for i in range(n):
        min_idx = i  # Assume first unsorted element is minimum
        for j in range(i + 1, n):
            yield list(arr), (min_idx, j), sorted_indices.copy()  # Highlight comparison
            if arr[j] < arr[min_idx]:
                min_idx = j  # Found new minimum
        arr[i], arr[min_idx] = arr[min_idx], arr[i]  # Swap minimum to correct position
        sorted_indices.add(i)
        yield list(arr), (-1, -1), sorted_indices.copy()
    sorted_indices = set(range(n))
    yield list(arr), (-1, -1), sorted_indices


def merge_sort_steps(arr):
    """
    Merge Sort generator for visualization.
    Divides array into halves recursively, then merges sorted halves.
    Time: O(n log n) | Space: O(n) for auxiliary array.
    Yields (full_array, compare_indices, sorted_indices) at each step.
    """
    aux = list(arr)
    sorted_indices = set()

    def merge(lo, mid, hi):
        """Merge two sorted halves: aux[lo..mid] and aux[mid+1..hi]."""
        left = aux[lo:mid + 1]    # Left half copy
        right = aux[mid + 1:hi + 1]  # Right half copy
        i = j = 0
        k = lo
        while i < len(left) and j < len(right):
            yield list(aux), (lo + i, mid + 1 + j), sorted_indices.copy()
            if left[i] <= right[j]:
                aux[k] = left[i]  # Take from left half
                i += 1
            else:
                aux[k] = right[j]  # Take from right half
                j += 1
            k += 1
        # Copy remaining elements
        while i < len(left):
            aux[k] = left[i]
            i += 1
            k += 1
        while j < len(right):
            aux[k] = right[j]
            j += 1
            k += 1
        yield list(aux), (-1, -1), sorted_indices.copy()

    def sort(lo, hi):
        """Recursively divide array and merge."""
        if lo < hi:
            mid = (lo + hi) // 2
            yield from sort(lo, mid)       # Sort left half
            yield from sort(mid + 1, hi)   # Sort right half
            yield from merge(lo, mid, hi)  # Merge sorted halves

    yield from sort(0, len(aux) - 1)
    sorted_indices = set(range(len(aux)))
    arr[:] = aux
    yield list(aux), (-1, -1), sorted_indices


# ---------------------------------------------------------------------------
# Pure sorting functions (no generators) — used by unit tests
# ---------------------------------------------------------------------------

def bubble_sort(arr):
    """Pure bubble sort — returns sorted list without visualization."""
    a = list(arr)
    n = len(a)
    for i in range(n):
        for j in range(0, n - i - 1):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
    return a


def selection_sort(arr):
    """Pure selection sort — returns sorted list without visualization."""
    a = list(arr)
    n = len(a)
    for i in range(n):
        mi = i
        for j in range(i + 1, n):
            if a[j] < a[mi]:
                mi = j
        a[i], a[mi] = a[mi], a[i]
    return a


def merge_sort(arr):
    """Pure merge sort — returns sorted list without visualization."""
    a = list(arr)
    if len(a) <= 1:
        return a
    mid = len(a) // 2
    left = merge_sort(a[:mid])   # Recursively sort left half
    right = merge_sort(a[mid:])  # Recursively sort right half
    return _merge(left, right)   # Merge sorted halves


def _merge(left, right):
    """Merge two sorted lists into one sorted list."""
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])   # Append remaining left elements
    result.extend(right[j:])  # Append remaining right elements
    return result


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

def sorting_module(screen, clock, width, height):
    """Sorting algorithms visualization module."""
    NUM_BARS = 40
    arr = [random.randint(10, height - 200) for _ in range(NUM_BARS)]
    bar_width = max(1, (width - 40) // NUM_BARS)

    algo_names = ["Bubble Sort", "Selection Sort", "Merge Sort"]
    algo_funcs = [bubble_sort_steps, selection_sort_steps, merge_sort_steps]
    current_algo = 0

    bubble_btn = Button(20, 60, 140, 35, "Bubble Sort", PRIMARY, font_size=18)
    sel_btn = Button(170, 60, 160, 35, "Selection Sort", PRIMARY, font_size=18)
    merge_btn = Button(340, 60, 140, 35, "Merge Sort", PRIMARY, font_size=18)
    start_btn = Button(510, 60, 90, 35, "Start", SUCCESS, font_size=20)
    reset_btn = Button(610, 60, 90, 35, "Reset", DANGER, font_size=20)
    speed_up = Button(710, 60, 35, 35, "+", WARNING, font_size=20)
    speed_dn = Button(750, 60, 35, 35, "-", WARNING, font_size=20)

    info = InfoPanel(530, 105, 260, 120)
    info.set_title("Sorting Info")

    running_sort = False
    sort_gen = None
    compare = (-1, -1)
    sorted_set = set()
    speed = 5  # steps per frame
    comparisons = 0

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, f"Sorting: {algo_names[current_algo]}", width)
        mouse = pygame.mouse.get_pos()
        for b in [bubble_btn, sel_btn, merge_btn, start_btn, reset_btn, speed_up, speed_dn]:
            b.update(mouse)
            b.draw(screen)
        info.draw(screen)

        # Speed label
        font_sm = pygame.font.SysFont("Arial", 16)
        screen.blit(font_sm.render(f"Speed: {speed}", True, DARK_GRAY), (712, 100))

        # Draw bars
        for i, val in enumerate(arr):
            x = 20 + i * bar_width
            if i in sorted_set:
                color = BAR_SORTED
            elif i == compare[0] or i == compare[1]:
                color = BAR_COMPARE
            else:
                color = BAR_DEFAULT
            pygame.draw.rect(screen, color, (x, height - 30 - val, bar_width - 2, val))

        # Step sort
        if running_sort and sort_gen:
            for _ in range(speed):
                try:
                    arr_snap, compare, sorted_set = next(sort_gen)
                    arr[:] = arr_snap
                    comparisons += 1
                except StopIteration:
                    running_sort = False
                    sorted_set = set(range(len(arr)))
                    compare = (-1, -1)
                    info.add_message(f"Done! {comparisons} steps")
                    break

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 14)
        screen.blit(instr_font.render(
            "HOW TO USE: Select algorithm → START to run | RESET for new array | +/- to change speed | ESC to go back",
            True, DARK_GRAY), (20, height - 20))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN:
                if bubble_btn.is_clicked(event.pos) and not running_sort:
                    current_algo = 0
                    info.add_message("Selected Bubble Sort")
                elif sel_btn.is_clicked(event.pos) and not running_sort:
                    current_algo = 1
                    info.add_message("Selected Selection Sort")
                elif merge_btn.is_clicked(event.pos) and not running_sort:
                    current_algo = 2
                    info.add_message("Selected Merge Sort")
                elif start_btn.is_clicked(event.pos) and not running_sort:
                    sort_gen = algo_funcs[current_algo](list(arr))
                    running_sort = True
                    comparisons = 0
                    sorted_set = set()
                    info.add_message(f"Starting {algo_names[current_algo]}")
                elif reset_btn.is_clicked(event.pos):
                    arr = [random.randint(10, height - 200) for _ in range(NUM_BARS)]
                    running_sort = False
                    sort_gen = None
                    compare = (-1, -1)
                    sorted_set = set()
                    info.add_message("Array reset")
                elif speed_up.is_clicked(event.pos):
                    speed = min(50, speed + 2)
                elif speed_dn.is_clicked(event.pos):
                    speed = max(1, speed - 2)
        clock.tick(30)
