"""
Phase 2: Min-Heap Visualizer
================================
Implements and visualizes a Min-Heap data structure:
  - Insert  : Add a value and bubble up to maintain heap property. O(log n)
  - Extract : Remove minimum (root), replace with last element, sift down. O(log n)
  - Peek    : View minimum value without removing it. O(1)
The heap is displayed as a binary tree with step-by-step animations.
"""

try:
    import pygame
    from utils.colors import (
        WHITE, GRAY, DARK_GRAY, MODULE_BG,
        SUCCESS, DANGER, WARNING, ACCENT, NODE_DEFAULT, NODE_CURRENT
    )
    from utils.ui import Button, TextInput, draw_header, InfoPanel
    _PYGAME_AVAILABLE = True
except ImportError:
    _PYGAME_AVAILABLE = False


# ---------------------------------------------------------------------------
# Min-heap logic (no Pygame dependency)
# ---------------------------------------------------------------------------

class MinHeap:
    """
    Min-Heap data structure backed by a Python list (array).
    Heap property: every parent node is smaller than or equal to its children.
    The minimum element is always at index 0 (the root).
    Uses 0-based indexing: parent(i) = (i-1)//2, left(i) = 2i+1, right(i) = 2i+2.
    """

    def __init__(self):
        self.heap = []  # Internal list representing the heap array

    def _parent(self, i):
        """Return the index of the parent node."""
        return (i - 1) // 2

    def _left(self, i):
        """Return the index of the left child."""
        return 2 * i + 1

    def _right(self, i):
        """Return the index of the right child."""
        return 2 * i + 2

    def insert(self, key):
        """Insert a new key into the heap. O(log n) time."""
        self.heap.append(key)           # Add to end of array
        self._bubble_up(len(self.heap) - 1)  # Restore heap property

    def _bubble_up(self, i):
        """Move element at index i up until heap property is satisfied."""
        while i > 0 and self.heap[self._parent(i)] > self.heap[i]:
            pi = self._parent(i)
            # Swap with parent if parent is larger
            self.heap[pi], self.heap[i] = self.heap[i], self.heap[pi]
            i = pi  # Move up to parent position

    def extract_min(self):
        """Remove and return the minimum element (root). O(log n) time."""
        if not self.heap:
            return None
        min_val = self.heap[0]   # Save minimum (root)
        last = self.heap.pop()   # Remove last element
        if self.heap:
            self.heap[0] = last  # Place last element at root
            self._sift_down(0)   # Restore heap property from root
        return min_val

    def _sift_down(self, i):
        """Move element at index i down until heap property is satisfied."""
        n = len(self.heap)
        while True:
            smallest = i
            left = self._left(i)
            right = self._right(i)
            # Find the smallest among node and its children
            if left < n and self.heap[left] < self.heap[smallest]:
                smallest = left
            if right < n and self.heap[right] < self.heap[smallest]:
                smallest = right
            if smallest == i:
                break  # Heap property satisfied, stop
            # Swap with smallest child and continue
            self.heap[i], self.heap[smallest] = self.heap[smallest], self.heap[i]
            i = smallest

    def peek(self):
        """Return the minimum element without removing it. O(1) time."""
        return self.heap[0] if self.heap else None

    def size(self):
        """Return the number of elements in the heap."""
        return len(self.heap)

    def is_empty(self):
        """Return True if the heap has no elements."""
        return len(self.heap) == 0

    def to_list(self):
        return list(self.heap)


# ---------------------------------------------------------------------------
# Step-by-step generators (for animation)
# ---------------------------------------------------------------------------

def insert_steps(heap_arr, key):
    """Yield (heap_copy, highlight_index) for each bubble-up swap."""
    heap_arr.append(key)
    i = len(heap_arr) - 1
    yield list(heap_arr), i
    while i > 0:
        pi = (i - 1) // 2
        if heap_arr[pi] > heap_arr[i]:
            heap_arr[pi], heap_arr[i] = heap_arr[i], heap_arr[pi]
            i = pi
            yield list(heap_arr), i
        else:
            break
    yield list(heap_arr), -1


def extract_steps(heap_arr):
    """Yield (heap_copy, highlight_index) for each sift-down swap."""
    if not heap_arr:
        return
    last = heap_arr.pop()
    if not heap_arr:
        yield [], -1
        return
    heap_arr[0] = last
    yield list(heap_arr), 0
    i = 0
    n = len(heap_arr)
    while True:
        smallest = i
        left = 2 * i + 1
        right = 2 * i + 2
        if left < n and heap_arr[left] < heap_arr[smallest]:
            smallest = left
        if right < n and heap_arr[right] < heap_arr[smallest]:
            smallest = right
        if smallest == i:
            break
        heap_arr[i], heap_arr[smallest] = heap_arr[smallest], heap_arr[i]
        i = smallest
        yield list(heap_arr), i
    yield list(heap_arr), -1


# ---------------------------------------------------------------------------
# Visualization
# ---------------------------------------------------------------------------

def heap_module(screen, clock, width, height):
    """Heap visualization module."""
    heap = MinHeap()
    text_input = TextInput(20, 65, 100, 35, "Value")
    insert_btn = Button(130, 65, 90, 35, "Insert", SUCCESS, font_size=20)
    extract_btn = Button(230, 65, 100, 35, "Extract", DANGER, font_size=20)
    step_btn = Button(340, 65, 80, 35, "Step", WARNING, font_size=20)
    auto_btn = Button(430, 65, 80, 35, "Auto", ACCENT, font_size=20)
    clear_btn = Button(520, 65, 80, 35, "Clear", GRAY, font_size=20)
    info = InfoPanel(620, 55, 170, 200)
    info.set_title("Heap Operations")

    anim_gen = None
    anim_highlight = -1
    auto_play = False
    auto_timer = 0
    display_arr = []

    NODE_RADIUS = 22

    def draw_heap_tree(arr, highlight):
        """Draw the heap as a binary tree."""
        if not arr:
            font = pygame.font.SysFont("Arial", 20)
            screen.blit(font.render("Empty heap — insert a value!", True, GRAY),
                        (width // 2 - 120, 200))
            return
        positions = []
        levels = 0
        count = len(arr)
        n = 0
        while n < count:
            levels += 1
            n = 2 ** levels - 1

        y_start = 150
        y_gap = 65
        for i in range(count):
            # Determine level
            level = 0
            temp = i + 1
            while temp > 1:
                temp //= 2
                level += 1
            nodes_in_level = 2 ** level
            pos_in_level = i - (2 ** level - 1)
            x_spacing = width // (nodes_in_level + 1)
            x = x_spacing * (pos_in_level + 1)
            y = y_start + level * y_gap
            positions.append((x, y))

        # Draw edges
        for i in range(count):
            left = 2 * i + 1
            right = 2 * i + 2
            if left < count:
                pygame.draw.line(screen, GRAY, positions[i], positions[left], 2)
            if right < count:
                pygame.draw.line(screen, GRAY, positions[i], positions[right], 2)

        # Draw nodes
        for i in range(count):
            x, y = positions[i]
            color = NODE_CURRENT if i == highlight else NODE_DEFAULT
            pygame.draw.circle(screen, color, (x, y), NODE_RADIUS)
            pygame.draw.circle(screen, DARK_GRAY, (x, y), NODE_RADIUS, 2)
            font = pygame.font.SysFont("Arial", 16, bold=True)
            t = font.render(str(arr[i]), True, WHITE)
            screen.blit(t, (x - t.get_width() // 2, y - t.get_height() // 2))

    def do_step():
        nonlocal anim_gen, anim_highlight, display_arr, auto_play
        if anim_gen:
            try:
                display_arr, anim_highlight = next(anim_gen)
            except StopIteration:
                anim_gen = None
                anim_highlight = -1
                auto_play = False
                display_arr = heap.to_list()
                info.add_message(f"Done  |  heap: {display_arr}")

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Min-Heap Visualizer", width)
        mouse = pygame.mouse.get_pos()
        for b in [insert_btn, extract_btn, step_btn, auto_btn, clear_btn]:
            b.update(mouse)
            b.draw(screen)
        text_input.draw(screen)
        info.draw(screen)

        # Draw array representation
        arr = heap.to_list()
        display_arr = arr
        font_sm = pygame.font.SysFont("Arial", 16)
        arr_str = "Array: [" + ", ".join(str(v) for v in arr) + "]"
        screen.blit(font_sm.render(arr_str, True, DARK_GRAY), (20, height - 40))

        draw_heap_tree(arr, anim_highlight)

        if auto_play and anim_gen:
            auto_timer += 1
            if auto_timer >= 20:
                auto_timer = 0
                do_step()

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 14)
        screen.blit(instr_font.render(
            "HOW TO USE: Type a number → INSERT to add | EXTRACT to remove min | STEP/AUTO to animate | ESC to go back",
            True, DARK_GRAY), (20, height - 20))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            text_input.handle_event(event)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if insert_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None and not anim_gen:
                        heap.insert(val)
                        display_arr = heap.to_list()
                        anim_highlight = -1
                        info.add_message(f"Inserted {val}  |  heap: {display_arr}")
                        text_input.clear()
                elif extract_btn.is_clicked(event.pos):
                    if not heap.is_empty() and not anim_gen:
                        min_val = heap.peek()
                        # Animate sift-down on a copy, sync real heap immediately
                        arr_copy = list(heap.heap)
                        heap.extract_min()          # Real heap updated right away
                        anim_gen = extract_steps(arr_copy)  # Step-by-step sift-down
                        info.add_message(f"Extracted min={min_val} — press STEP or AUTO to animate sift-down")
                elif step_btn.is_clicked(event.pos):
                    do_step()
                elif auto_btn.is_clicked(event.pos):
                    auto_play = not auto_play
                    auto_timer = 0
                    info.add_message("Auto " + ("ON" if auto_play else "OFF"))
                elif clear_btn.is_clicked(event.pos):
                    heap = MinHeap()
                    anim_gen = None
                    display_arr = []
                    anim_highlight = -1
                    auto_play = False
                    info.add_message("Heap cleared")
        clock.tick(30)
