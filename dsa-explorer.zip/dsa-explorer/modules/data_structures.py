"""
Phase 1: Data Structure Playground
=====================================
Implements and visualizes four core data structures:
  - Stack  : LIFO (Last In, First Out) with push/pop
  - Queue  : FIFO (First In, First Out) with enqueue/dequeue
  - Linked List : insert/delete/reverse with pointer visualization
  - BST   : Binary Search Tree with in/pre/post-order traversal
"""

try:
    import pygame
    from utils.colors import (
        WHITE, GRAY, DARK_GRAY, PRIMARY, MODULE_BG,
        STACK_COLOR, QUEUE_COLOR, LINKED_LIST_COLOR, BST_COLOR,
        SUCCESS, DANGER, WARNING, ACCENT
    )
    from utils.ui import Button, TextInput, draw_header, InfoPanel
    _PYGAME_AVAILABLE = True
except ImportError:
    _PYGAME_AVAILABLE = False


# ---------------------------------------------------------------------------
# Data-structure logic (no Pygame dependency) -- used by tests too
# ---------------------------------------------------------------------------

class Stack:
    """
    Stack - LIFO (Last In, First Out).
    Push adds to the top; Pop removes from the top.
    Time complexity: push O(1), pop O(1), peek O(1).
    """

    def __init__(self, max_size=10):
        self.items = []  # Internal list; end of list = top of stack
        self.max_size = max_size

    def push(self, item):
        """Add item to top of stack. Returns False if stack is full."""
        if len(self.items) < self.max_size:
            self.items.append(item)  # Append to end = push to top
            return True
        return False  # Stack overflow

    def pop(self):
        """Remove and return top item. Returns None if empty."""
        if self.items:
            return self.items.pop()  # Remove from end = pop from top
        return None  # Stack underflow

    def peek(self):
        """Return top item without removing it. Returns None if empty."""
        if self.items:
            return self.items[-1]  # Last element = top of stack
        return None

    def is_empty(self):
        """Return True if the stack has no elements."""
        return len(self.items) == 0

    def size(self):
        """Return the number of elements in the stack."""
        return len(self.items)


class Queue:
    """
    Queue - FIFO (First In, First Out).
    Enqueue adds to the back; Dequeue removes from the front.
    Time complexity: enqueue O(1), dequeue O(n), front O(1).
    """

    def __init__(self, max_size=10):
        self.items = []          # Internal list; index 0 = front of queue
        self.max_size = max_size # Maximum number of elements allowed

    def enqueue(self, item):
        """Add item to the back of the queue. Returns False if full."""
        if len(self.items) < self.max_size:
            self.items.append(item)  # Add to end = back of queue
            return True
        return False  # Queue is full

    def dequeue(self):
        """Remove and return the front item. Returns None if empty."""
        if self.items:
            return self.items.pop(0)  # Remove from front (index 0)
        return None  # Queue is empty

    def front(self):
        """Return the front item without removing it. Returns None if empty."""
        if self.items:
            return self.items[0]  # First element = front of queue
        return None

    def is_empty(self):
        """Return True if the queue has no elements."""
        return len(self.items) == 0

    def size(self):
        """Return the number of elements in the queue."""
        return len(self.items)


class LinkedListNode:
    """A single node in a singly linked list."""

    def __init__(self, data):
        self.data = data  # Value stored in this node
        self.next = None  # Pointer to the next node (None if last node)


class LinkedList:
    """
    Singly Linked List.
    Each node holds data and a pointer to the next node.
    Supports insert at head/tail, delete, reverse, and search.
    Time complexity: insert_head O(1), insert_tail O(n), delete O(n), reverse O(n).
    """

    def __init__(self):
        self.head = None  # First node; None means the list is empty

    def insert_at_head(self, data):
        """Insert a new node at the beginning. O(1) time."""
        new_node = LinkedListNode(data)
        new_node.next = self.head  # New node points to old head
        self.head = new_node       # Update head to new node

    def insert_at_tail(self, data):
        """Insert a new node at the end. O(n) time."""
        new_node = LinkedListNode(data)
        if not self.head:
            self.head = new_node  # Empty list: new node becomes head
            return
        # Traverse to the last node
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node  # Link last node to new node

    def insert_at_position(self, index, data):
        """Insert a new node at a specified 0-based position. O(n) time.
        index <= 0  → inserts at head.
        index >= size → inserts at tail.
        """
        new_node = LinkedListNode(data)
        if index <= 0 or not self.head:
            new_node.next = self.head   # Point new node to old head
            self.head = new_node        # New node becomes head
            return
        current = self.head
        for _ in range(index - 1):     # Walk to the node just before target
            if not current.next:
                break
            current = current.next
        new_node.next = current.next   # New node points to successor
        current.next = new_node        # Predecessor points to new node

    def delete_node(self, data):
        """Delete the first node with the given value. O(n) time."""
        if not self.head:
            return False  # Empty list
        if self.head.data == data:
            self.head = self.head.next  # Remove head node
            return True
        # Traverse to find the node just before the target
        current = self.head
        while current.next:
            if current.next.data == data:
                current.next = current.next.next  # Skip target node
                return True
            current = current.next
        return False  # Data not found

    def reverse(self):
        """Reverse the linked list in-place. O(n) time."""
        prev = None
        current = self.head
        while current:
            next_node = current.next  # Save next before overwriting
            current.next = prev       # Reverse the pointer direction
            prev = current            # Move prev one step forward
            current = next_node       # Move current one step forward
        self.head = prev  # Update head to what was the last node

    def to_list(self):
        """Convert linked list to a Python list for easy inspection."""
        result = []
        current = self.head
        while current:
            result.append(current.data)
            current = current.next
        return result

    def size(self):
        """Return the number of nodes in the list."""
        return len(self.to_list())

    def search(self, data):
        """Return index of first node with given data, or -1 if not found."""
        current = self.head
        index = 0
        while current:
            if current.data == data:
                return index
            current = current.next
            index += 1
        return -1


class BSTNode:
    """A single node in a Binary Search Tree."""

    def __init__(self, key):
        self.key = key    # Value stored in this node
        self.left = None  # Left child (values smaller than key)
        self.right = None # Right child (values larger than key)


class BST:
    """
    Binary Search Tree (BST).
    Property: left subtree < node < right subtree.
    Supports insert, search, and in/pre/post-order traversals.
    Average time complexity: insert O(log n), search O(log n).
    """

    def __init__(self):
        self.root = None  # Root node; None means tree is empty

    def insert(self, key):
        """Insert a key into the BST. Duplicates are ignored."""
        self.root = self._insert(self.root, key)

    def _insert(self, node, key):
        """Recursive helper: find correct position and insert."""
        if node is None:
            return BSTNode(key)       # Create new node at empty spot
        if key < node.key:
            node.left = self._insert(node.left, key)   # Go left
        elif key > node.key:
            node.right = self._insert(node.right, key) # Go right
        # key == node.key: duplicate, do nothing
        return node

    def inorder(self):
        """Return values in sorted order: Left -> Root -> Right."""
        result = []
        self._inorder(self.root, result)
        return result

    def _inorder(self, node, result):
        """Recursive in-order traversal."""
        if node:
            self._inorder(node.left, result)   # Visit left subtree first
            result.append(node.key)             # Then visit root
            self._inorder(node.right, result)  # Then visit right subtree

    def preorder(self):
        """Return values in pre-order: Root -> Left -> Right."""
        result = []
        self._preorder(self.root, result)
        return result

    def _preorder(self, node, result):
        """Recursive pre-order traversal."""
        if node:
            result.append(node.key)              # Visit root first
            self._preorder(node.left, result)   # Then left subtree
            self._preorder(node.right, result)  # Then right subtree

    def postorder(self):
        """Return values in post-order: Left -> Right -> Root."""
        result = []
        self._postorder(self.root, result)
        return result

    def _postorder(self, node, result):
        """Recursive post-order traversal."""
        if node:
            self._postorder(node.left, result)  # Visit left subtree first
            self._postorder(node.right, result) # Then right subtree
            result.append(node.key)              # Visit root last

    def delete(self, key):
        """Delete a node by key. Handles 0, 1, and 2 child cases. O(log n) avg."""
        self.root = self._delete(self.root, key)

    def _delete(self, node, key):
        """Recursive helper for BST deletion."""
        if node is None:
            return None                        # Key not found; nothing to do
        if key < node.key:
            node.left = self._delete(node.left, key)   # Search left
        elif key > node.key:
            node.right = self._delete(node.right, key) # Search right
        else:
            # CASE 0 / 1: No left child → replace node with right child
            if node.left is None:
                return node.right
            # CASE 1: No right child → replace node with left child
            if node.right is None:
                return node.left
            # CASE 2: Two children → find in-order successor (min of right subtree)
            successor = node.right
            while successor.left:
                successor = successor.left
            node.key = successor.key           # Copy successor's value up
            node.right = self._delete(node.right, successor.key)  # Remove successor
        return node

    def search(self, key):
        """Return True if key exists in the BST."""
        return self._search(self.root, key)

    def _search(self, node, key):
        """Recursive helper: search left or right based on comparison."""
        if node is None:
            return False       # Key not found
        if key == node.key:
            return True        # Key found
        if key < node.key:
            return self._search(node.left, key)  # Search left subtree
        return self._search(node.right, key)     # Search right subtree


# ---------------------------------------------------------------------------
# Sub-module selection screen
# ---------------------------------------------------------------------------

def _sub_menu(screen, clock, width, height):
    """Let the user choose Stack, Queue, Linked List or BST."""
    buttons = [
        Button(width // 2 - 120, 150, 240, 50, "Stack", STACK_COLOR),
        Button(width // 2 - 120, 220, 240, 50, "Queue", QUEUE_COLOR),
        Button(width // 2 - 120, 290, 240, 50, "Linked List", LINKED_LIST_COLOR),
        Button(width // 2 - 120, 360, 240, 50, "Binary Search Tree", BST_COLOR),
    ]
    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Data Structure Playground", width)
        mouse = pygame.mouse.get_pos()
        for b in buttons:
            b.update(mouse)
            b.draw(screen)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            if event.type == pygame.MOUSEBUTTONDOWN:
                for i, b in enumerate(buttons):
                    if b.is_clicked(event.pos):
                        return ["stack", "queue", "linkedlist", "bst"][i]
        clock.tick(30)


# ---------------------------------------------------------------------------
# Stack visualization
# ---------------------------------------------------------------------------

def _stack_module(screen, clock, width, height):
    stack = Stack()
    text_input = TextInput(20, 70, 100, 35, "Value")
    push_btn = Button(130, 70, 90, 35, "Push", SUCCESS, font_size=20)
    pop_btn = Button(230, 70, 90, 35, "Pop", DANGER, font_size=20)
    peek_btn = Button(330, 70, 90, 35, "Peek", WARNING, font_size=20)
    clear_btn = Button(430, 70, 90, 35, "Clear", GRAY, font_size=20)
    info = InfoPanel(540, 60, 250, 200)
    info.set_title("Stack Operations")
    highlight_idx = -1
    highlight_timer = 0

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Stack Visualization", width)
        mouse = pygame.mouse.get_pos()
        for b in [push_btn, pop_btn, peek_btn, clear_btn]:
            b.update(mouse)
            b.draw(screen)
        text_input.draw(screen)
        info.draw(screen)

        # Draw stack
        base_x, base_y = width // 2 - 40, height - 60
        box_w, box_h = 100, 40
        for i, item in enumerate(stack.items):
            y = base_y - (i + 1) * (box_h + 5)
            color = ACCENT if i == highlight_idx else STACK_COLOR
            pygame.draw.rect(screen, color, (base_x, y, box_w, box_h), border_radius=4)
            pygame.draw.rect(screen, DARK_GRAY, (base_x, y, box_w, box_h), 2, border_radius=4)
            font = pygame.font.SysFont("Arial", 22)
            t = font.render(str(item), True, WHITE)
            screen.blit(t, (base_x + box_w // 2 - t.get_width() // 2, y + 8))
        # Base line
        pygame.draw.line(screen, DARK_GRAY, (base_x - 10, base_y), (base_x + box_w + 10, base_y), 3)
        # Top pointer
        if not stack.is_empty():
            top_y = base_y - len(stack.items) * (box_h + 5)
            font_sm = pygame.font.SysFont("Arial", 16)
            arrow_txt = font_sm.render("TOP ->", True, DANGER)
            screen.blit(arrow_txt, (base_x - 65, top_y + 10))

        if highlight_timer > 0:
            highlight_timer -= 1
        else:
            highlight_idx = -1

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 14)
        instr_lines = [
            "HOW TO USE: Type a number → PUSH to add | POP to remove | PEEK to view top | ESC to go back"
        ]
        screen.blit(instr_font.render(instr_lines[0], True, DARK_GRAY), (20, height - 25))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            text_input.handle_event(event)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if push_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        if stack.push(val):
                            info.add_message(f"Pushed {val}")
                            highlight_idx = len(stack.items) - 1
                            highlight_timer = 30
                        else:
                            info.add_message("Stack is full!")
                        text_input.clear()
                elif pop_btn.is_clicked(event.pos):
                    val = stack.pop()
                    if val is not None:
                        info.add_message(f"Popped {val}")
                    else:
                        info.add_message("Stack is empty!")
                elif peek_btn.is_clicked(event.pos):
                    val = stack.peek()
                    if val is not None:
                        info.add_message(f"Top: {val}")
                        highlight_idx = len(stack.items) - 1
                        highlight_timer = 30
                    else:
                        info.add_message("Stack is empty!")
                elif clear_btn.is_clicked(event.pos):
                    stack.items.clear()
                    info.add_message("Stack cleared")
        clock.tick(30)


# ---------------------------------------------------------------------------
# Queue visualization
# ---------------------------------------------------------------------------

def _queue_module(screen, clock, width, height):
    queue = Queue()
    text_input = TextInput(20, 70, 100, 35, "Value")
    enq_btn = Button(130, 70, 110, 35, "Enqueue", SUCCESS, font_size=20)
    deq_btn = Button(250, 70, 110, 35, "Dequeue", DANGER, font_size=20)
    front_btn = Button(370, 70, 90, 35, "Front", WARNING, font_size=20)
    clear_btn = Button(470, 70, 90, 35, "Clear", GRAY, font_size=20)
    info = InfoPanel(580, 60, 210, 200)
    info.set_title("Queue Operations")
    highlight_idx = -1
    highlight_timer = 0

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Queue Visualization", width)
        mouse = pygame.mouse.get_pos()
        for b in [enq_btn, deq_btn, front_btn, clear_btn]:
            b.update(mouse)
            b.draw(screen)
        text_input.draw(screen)
        info.draw(screen)

        # Draw queue horizontally
        start_x, y = 60, height // 2 - 25
        box_w, box_h = 60, 50
        for i, item in enumerate(queue.items):
            x = start_x + i * (box_w + 10)
            color = ACCENT if i == highlight_idx else QUEUE_COLOR
            pygame.draw.rect(screen, color, (x, y, box_w, box_h), border_radius=4)
            pygame.draw.rect(screen, DARK_GRAY, (x, y, box_w, box_h), 2, border_radius=4)
            font = pygame.font.SysFont("Arial", 22)
            t = font.render(str(item), True, WHITE)
            screen.blit(t, (x + box_w // 2 - t.get_width() // 2, y + 12))
            # Arrow
            if i < len(queue.items) - 1:
                ax = x + box_w + 1
                pygame.draw.line(screen, DARK_GRAY, (ax, y + box_h // 2), (ax + 8, y + box_h // 2), 2)
                pygame.draw.polygon(screen, DARK_GRAY, [
                    (ax + 8, y + box_h // 2 - 5),
                    (ax + 8, y + box_h // 2 + 5),
                    (ax + 13, y + box_h // 2)
                ])

        font_sm = pygame.font.SysFont("Arial", 16)
        if not queue.is_empty():
            fx = start_x + 10
            screen.blit(font_sm.render("FRONT", True, SUCCESS), (fx, y + box_h + 8))
            rx = start_x + (len(queue.items) - 1) * (box_w + 10) + 10
            screen.blit(font_sm.render("REAR", True, DANGER), (rx, y + box_h + 8))

        if highlight_timer > 0:
            highlight_timer -= 1
        else:
            highlight_idx = -1

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 14)
        screen.blit(instr_font.render(
            "HOW TO USE: Type a number → ENQUEUE to add to rear | DEQUEUE to remove from front | ESC to go back",
            True, DARK_GRAY), (20, height - 25))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            text_input.handle_event(event)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if enq_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        if queue.enqueue(val):
                            info.add_message(f"Enqueued {val}")
                            highlight_idx = len(queue.items) - 1
                            highlight_timer = 30
                        else:
                            info.add_message("Queue is full!")
                        text_input.clear()
                elif deq_btn.is_clicked(event.pos):
                    val = queue.dequeue()
                    if val is not None:
                        info.add_message(f"Dequeued {val}")
                    else:
                        info.add_message("Queue is empty!")
                elif front_btn.is_clicked(event.pos):
                    val = queue.front()
                    if val is not None:
                        info.add_message(f"Front: {val}")
                        highlight_idx = 0
                        highlight_timer = 30
                    else:
                        info.add_message("Queue is empty!")
                elif clear_btn.is_clicked(event.pos):
                    queue.items.clear()
                    info.add_message("Queue cleared")
        clock.tick(30)


# ---------------------------------------------------------------------------
# Linked List visualization
# ---------------------------------------------------------------------------

def _linkedlist_module(screen, clock, width, height):
    ll = LinkedList()
    text_input = TextInput(20, 70, 120, 35, "Value")
    head_btn  = Button(150, 70, 115, 35, "Ins Head",  SUCCESS,  font_size=17)
    tail_btn  = Button(272, 70, 115, 35, "Ins Tail",  PRIMARY,  font_size=17)
    del_btn   = Button(394, 70, 90,  35, "Delete",    DANGER,   font_size=17)
    rev_btn   = Button(491, 70, 90,  35, "Reverse",   WARNING,  font_size=17)
    clear_btn = Button(588, 70, 75,  35, "Clear",     GRAY,     font_size=17)
    info = InfoPanel(20, height - 160, 760, 150)
    info.set_title("Linked List Operations")

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Linked List Visualization", width)
        mouse = pygame.mouse.get_pos()
        for b in [head_btn, tail_btn, del_btn, rev_btn, clear_btn]:
            b.update(mouse)
            b.draw(screen)
        text_input.draw(screen)
        info.draw(screen)

        # Draw linked list nodes
        items = ll.to_list()
        start_x, y = 40, height // 2 - 30
        node_w, node_h = 60, 50
        gap = 30
        for i, item in enumerate(items):
            x = start_x + i * (node_w + gap)
            if x + node_w > width - 20:
                break
            pygame.draw.rect(screen, LINKED_LIST_COLOR, (x, y, node_w, node_h), border_radius=6)
            pygame.draw.rect(screen, DARK_GRAY, (x, y, node_w, node_h), 2, border_radius=6)
            font = pygame.font.SysFont("Arial", 20)
            t = font.render(str(item), True, WHITE)
            screen.blit(t, (x + node_w // 2 - t.get_width() // 2, y + 13))
            # Arrow to next node
            if i < len(items) - 1:
                ax = x + node_w
                ay = y + node_h // 2
                pygame.draw.line(screen, DARK_GRAY, (ax, ay), (ax + gap - 5, ay), 2)
                pygame.draw.polygon(screen, DARK_GRAY, [
                    (ax + gap - 5, ay - 5), (ax + gap - 5, ay + 5), (ax + gap, ay)
                ])
            # NULL terminator after the last node
            elif i == len(items) - 1:
                ax = x + node_w
                ay = y + node_h // 2
                null_x = ax + gap
                pygame.draw.line(screen, DARK_GRAY, (ax, ay), (null_x - 2, ay), 2)
                pygame.draw.polygon(screen, DARK_GRAY, [
                    (null_x - 2, ay - 5), (null_x - 2, ay + 5), (null_x + 3, ay)
                ])
                null_w, null_h = 40, 26
                null_rect = (null_x + 3, ay - null_h // 2, null_w, null_h)
                pygame.draw.rect(screen, GRAY, null_rect, border_radius=4)
                pygame.draw.rect(screen, DARK_GRAY, null_rect, 1, border_radius=4)
                font_null = pygame.font.SysFont("Arial", 13, bold=True)
                nt = font_null.render("NULL", True, WHITE)
                screen.blit(nt, (null_x + 3 + null_w // 2 - nt.get_width() // 2, ay - nt.get_height() // 2))

        if items:
            font_sm = pygame.font.SysFont("Arial", 14)
            screen.blit(font_sm.render("HEAD", True, SUCCESS), (start_x + 10, y - 20))
        if not items:
            font = pygame.font.SysFont("Arial", 20)
            screen.blit(font.render("Empty list — insert a node!", True, GRAY), (start_x, y + 10))

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 14)
        screen.blit(instr_font.render(
            "HOW TO USE: Value + Ins Head / Ins Tail to insert  |  Delete to remove  |  Reverse  |  ESC back",
            True, DARK_GRAY), (20, height - 25))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            text_input.handle_event(event)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if head_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        ll.insert_at_head(val)
                        info.add_message(f"Inserted {val} at head")
                        text_input.clear()
                elif tail_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        ll.insert_at_tail(val)
                        info.add_message(f"Inserted {val} at tail")
                        text_input.clear()
                elif del_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        if ll.delete_node(val):
                            info.add_message(f"Deleted {val}")
                        else:
                            info.add_message(f"{val} not found")
                        text_input.clear()
                elif rev_btn.is_clicked(event.pos):
                    ll.reverse()
                    info.add_message("List reversed")
                elif clear_btn.is_clicked(event.pos):
                    ll.head = None
                    info.add_message("List cleared")
        clock.tick(30)


# ---------------------------------------------------------------------------
# BST visualization
# ---------------------------------------------------------------------------

def _bst_module(screen, clock, width, height):
    bst = BST()
    text_input = TextInput(20, 70, 100, 35, "Value")
    insert_btn    = Button(130, 70, 90,  35, "Insert",     SUCCESS, font_size=18)
    delete_btn    = Button(226, 70, 90,  35, "Delete",     DANGER,  font_size=18)
    search_btn    = Button(322, 70, 90,  35, "Search",     WARNING, font_size=18)
    clear_btn     = Button(418, 70, 70,  35, "Clear",      GRAY,    font_size=18)
    inorder_btn   = Button(494, 70, 95,  35, "In-order",   PRIMARY, font_size=17)
    preorder_btn  = Button(595, 70, 100, 35, "Pre-order",  PRIMARY, font_size=17)
    postorder_btn = Button(701, 70, 105, 35, "Post-order", PRIMARY, font_size=17)
    info = InfoPanel(20, height - 140, 760, 130)
    info.set_title("BST Operations")
    search_key = None
    search_timer = 0

    def draw_tree(node, x, y, x_offset, depth=0):
        if not node:
            return
        is_search_hit = (search_key is not None and node.key == search_key and search_timer > 0)
        color = ACCENT if is_search_hit else BST_COLOR
        if node.left:
            pygame.draw.line(screen, GRAY, (x, y), (x - x_offset, y + 70), 2)
            draw_tree(node.left, x - x_offset, y + 70, x_offset // 2, depth + 1)
        if node.right:
            pygame.draw.line(screen, GRAY, (x, y), (x + x_offset, y + 70), 2)
            draw_tree(node.right, x + x_offset, y + 70, x_offset // 2, depth + 1)
        pygame.draw.circle(screen, color, (x, y), 22)
        pygame.draw.circle(screen, DARK_GRAY, (x, y), 22, 2)
        font = pygame.font.SysFont("Arial", 18)
        t = font.render(str(node.key), True, WHITE)
        screen.blit(t, (x - t.get_width() // 2, y - t.get_height() // 2))

    while True:
        screen.fill(MODULE_BG)
        draw_header(screen, "Binary Search Tree", width)
        mouse = pygame.mouse.get_pos()
        for b in [insert_btn, delete_btn, search_btn, clear_btn, inorder_btn, preorder_btn, postorder_btn]:
            b.update(mouse)
            b.draw(screen)
        text_input.draw(screen)
        info.draw(screen)

        # Draw BST
        if bst.root:
            draw_tree(bst.root, width // 2, 150, width // 5)
        else:
            font = pygame.font.SysFont("Arial", 20)
            screen.blit(font.render("Empty tree — insert a node!", True, GRAY), (width // 2 - 120, 200))

        if search_timer > 0:
            search_timer -= 1

        # On-screen instructions
        instr_font = pygame.font.SysFont("Arial", 14)
        screen.blit(instr_font.render(
            "HOW TO USE: Type a number → INSERT | DELETE (0/1/2 child) | SEARCH | In/Pre/Post-order | ESC to go back",
            True, DARK_GRAY), (20, height - 25))

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return None
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"
            text_input.handle_event(event)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if insert_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        bst.insert(val)
                        info.add_message(f"Inserted {val}")
                        text_input.clear()
                elif search_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        found = bst.search(val)
                        if found:
                            info.add_message(f"Found {val}")
                            search_key = val
                            search_timer = 60
                        else:
                            info.add_message(f"{val} not found")
                        text_input.clear()
                elif delete_btn.is_clicked(event.pos):
                    val = text_input.get_value()
                    if val is not None:
                        bst.delete(val)
                        info.add_message(f"Deleted node {val}")
                        text_input.clear()
                    else:
                        info.add_message("Enter a value to delete")
                elif clear_btn.is_clicked(event.pos):
                    bst.root = None
                    info.add_message("Tree cleared")
                elif inorder_btn.is_clicked(event.pos):
                    result = bst.inorder()
                    info.add_message(f"In-order: {result}")
                elif preorder_btn.is_clicked(event.pos):
                    result = bst.preorder()
                    info.add_message(f"Pre-order: {result}")
                elif postorder_btn.is_clicked(event.pos):
                    result = bst.postorder()
                    info.add_message(f"Post-order: {result}")
        clock.tick(30)


# ---------------------------------------------------------------------------
# Module entry point
# ---------------------------------------------------------------------------

def data_structures_module(screen, clock, width, height):
    """Entry point for Phase 1 data-structures playground."""
    while True:
        choice = _sub_menu(screen, clock, width, height)
        if choice is None:
            return None
        if choice == "back":
            return "back"
        handlers = {
            "stack": _stack_module,
            "queue": _queue_module,
            "linkedlist": _linkedlist_module,
            "bst": _bst_module,
        }
        result = handlers[choice](screen, clock, width, height)
        if result is None:
            return None
        # "back" from a sub-module returns to the sub-menu
